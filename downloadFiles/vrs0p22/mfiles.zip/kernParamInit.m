function kern = kernParamInit(kern)

% KERNPARAMINIT Kernel parameter initialisation.
%
% kern = kernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Thu Apr  8 16:01:13 2004
% IVM toolbox version 0.22



kern = feval([kern.type 'KernParamInit'], kern);
