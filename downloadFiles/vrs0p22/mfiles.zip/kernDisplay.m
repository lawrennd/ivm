function kernDisplay(kern)

% KERNDISPLAY Display the parameters of the kernel.
%
% kernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:43:58 2004
% IVM toolbox version 0.22



feval([kern.type 'KernDisplay'], kern)