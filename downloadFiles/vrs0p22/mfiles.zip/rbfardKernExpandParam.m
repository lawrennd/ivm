function kern = rbfardKernExpandParam(kern, params)

% RBFARDKERNEXPANDPARAM Create kernel structure from radial basis function ARD's parameters.
%
% kern = rbfardKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Fri Apr 16 00:58:09 2004
% IVM toolbox version 0.22


kern.inverseWidth = params(1);
kern.variance = params(2);
kern.inputScales = params(3:end);
