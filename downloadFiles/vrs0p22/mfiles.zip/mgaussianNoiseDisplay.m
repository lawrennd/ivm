function mgaussianNoiseDisplay(noise)

% MGAUSSIANNOISEDISPLAY Display  parameters from Variable variance Gaussian noise model.
%
% mgaussianNoiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Apr 14 01:07:18 2004
% IVM toolbox version 0.22




for i = 1:noise.numProcess
  fprintf('MGaussian bias on process %d: %2.4f\n', i, noise.bias(i))
  fprintf('MGaussian variance on process %d: %2.4f\n', i, noise.sigma2(i))
end

