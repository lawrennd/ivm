function y = cmpndNoiseOut(noise, mu, varsigma)

% CMPNDNOISEOUT Output from compound noise model.
%
% y = cmpndNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Apr 14 18:16:09 2004
% IVM toolbox version 0.22



y = zeros(size(mu));
for i = 1:length(noise.comp)
  y(:, i) = feval([noise.comp{i}.type 'NoiseOut'], ...
                noise.comp{i},...
                mu(:, i), ...
                varsigma(:, i));
end

