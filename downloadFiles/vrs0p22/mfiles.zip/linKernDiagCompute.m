function k = linKernDiagCompute(kern, x)

% LINKERNDIAGCOMPUTE Compute diagonal of linear kernel.
%
% k = linKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:29:49 2004
% IVM toolbox version 0.22



linPart = ones(size(x, 1), 1);
k =  sum(x.*x, 2)*kern.variance;
