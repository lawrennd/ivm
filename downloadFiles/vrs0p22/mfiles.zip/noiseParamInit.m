function noise = noiseParamInit(noise, y)

% NOISEPARAMINIT Noise model's parameter initialisation.
%
% noise = noiseParamInit(noise, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Mar 19 18:53:08 2004
% IVM toolbox version 0.22



if nargin > 1
  noise = feval([noise.type 'NoiseParamInit'], noise, y);
else
  noise = feval([noise.type 'NoiseParamInit'], noise);
end
