function kern = kernCreate(X, kernelType)

% KERNCREATE Initialise a kernel structure.
%
% kern = kernCreate(X, kernelType)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr 22 01:25:53 2004
% IVM toolbox version 0.22



kern.Kstore = [];
kern.diagK = [];
if iscell(kernelType)
  % compound kernel type
  kern.type = 'cmpnd';
  for i = 1:length(kernelType)
    kern.comp{i}.type = kernelType{i};
    kern.comp{i}.inputDimension = size(X, 2);
  end
else
  kern.type = kernelType;
  kern.inputDimension = size(X, 2);
end
kern = kernParamInit(kern);
