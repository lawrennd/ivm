function gX = rbfardKernDiagGradX(kern, x)

% RBFARDKERNDIAGGRADX Gradient of radial basis function ARD kernel's diagonal with respect to a point x.
%
% gX = rbfardKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 17:19:34 2004
% IVM toolbox version 0.22



gX = zeros(size(x));