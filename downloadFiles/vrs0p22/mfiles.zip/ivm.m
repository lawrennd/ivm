function model = ivm(X, y, kernelType, noiseType, selectionCriterion, d)

% IVM Initialise an IVM model.
%
% model = ivm(X, y, kernelType, noiseType, selectionCriterion, d)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Thu Apr 22 01:25:27 2004
% IVM toolbox version 0.22


% Version 0.1

model.d = d;

model.X = X;
model.y = y;

model.m = [];
model.beta = [];

model.nu = zeros(size(y));
model.g = zeros(size(y));

model.kern = kernCreate(X, kernelType);
  
model.varSigma = zeros(size(y));
model.mu = zeros(size(y));

model.I = [];
model.J = [];

if strcmp(noiseType, 'gaussian')
  model.Sigma.M = [];
  model.Sigma.L = [];
  model.Sigma.robust = 0;
else
  for i = 1:size(y, 2)
    model.Sigma(i).M = [];
    model.Sigma(i).L = [];
    model.Sigma(i).robust = 1;
  end
end
model.selectionCriterion = selectionCriterion;

model.noise = noiseCreate(noiseType, y); 

switch selectionCriterion
 case 'none'
  numData = size(X, 1);
  model.I = (1:numData);
 otherwise
  
end