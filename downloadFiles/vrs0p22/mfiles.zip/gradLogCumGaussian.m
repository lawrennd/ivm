function y = gradLogCumGaussian(x)

% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
%
% y = gradLogCumGaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Apr 13 18:24:18 2004
% IVM toolbox version 0.22



% Theoretically this is simply ngaussian(x)/cumGaussian(x) but there are
% problems in the tails of the distribution.

    %.5*erfcx(-sqrt(2)/2*x)=exp(.5*x*x)*cumGaussian(x) ...

y = zeros(size(x));
index = find(x>0);
y(index) = ngaussian(x(index))./cumGaussian(x(index));
x(index) = NaN;
index = find(x<=0);
y(index) = 1./(sqrt(2*pi)*0.5*erfcx(-sqrt(2)/2*x(index)));
