function cmpndNoiseDisplay(noise)

% CMPNDNOISEDISPLAY Display the parameters of the compound noise model.
%
% cmpndNoiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Apr 13 15:55:07 2004
% IVM toolbox version 0.22



for i = 1:length(noise.comp)
  noiseDisplay(noise.comp{i});
end