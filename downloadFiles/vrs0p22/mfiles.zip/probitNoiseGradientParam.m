function g = probitNoiseGradientParam(noise, mu, varsigma, y)

% PROBITNOISEGRADIENTPARAM Gradient of the probit noise model's parameters.
%
% g = probitNoiseGradientParam(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Apr 14 18:27:21 2004
% IVM toolbox version 0.22



c = y./sqrt(1+ varsigma);
for i = 1:size(mu, 2)
  u(:, i) = c(:, i).*(mu(:, i) + noise.bias(i));
end
g = sum(c.*gradLogCumGaussian(u), 1);