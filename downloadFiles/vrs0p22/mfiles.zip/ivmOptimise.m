function model = ivmOptimise(model, prior, display, innerIters, ...
			     outerIters);

% IVMOPTIMISE Optimise the IVM.
%
% model = ivmOptimise(model, prior, display, innerIters, ...
% 			     outerIters);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.5, Mon Apr 12 18:00:49 2004
% IVM toolbox version 0.22



% Run IVM
for i = 1:outerIters
  model = ivmOptimiseIVM(model, display);
  model = ivmOptimiseKernel(model, prior, display, innerIters);
  model = ivmOptimiseIVM(model, display);
  model = ivmOptimiseNoise(model, prior, display, innerIters);
end
