function k = rbfKernDiagCompute(kern, x)

% RBFKERNDIAGCOMPUTE Compute diagonal of rbf kernel.
%
% k = rbfKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:29:59 2004
% IVM toolbox version 0.22



rbfPart = ones(size(x, 1), 1);
k = rbfPart*kern.variance;
