function g = linKernGradient(kern, x, covGrad)

% LINKERNGRADIENT Gradient of lin kernel's parameters.
%
% g = linKernGradient(kern, x, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 00:26:13 2004
% IVM toolbox version 0.22



linPart = linKernCompute(kern, x);
g(1) = sum(sum(covGrad.*linPart))/kern.variance;
