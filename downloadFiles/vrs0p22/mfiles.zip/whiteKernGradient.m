function g = whiteKernGradient(kern, x, covGrad)

% WHITEKERNGRADIENT Gradient of white noise kernel's parameters.
%
% g = whiteKernGradient(kern, x, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 01:16:53 2004
% IVM toolbox version 0.22



g = trace(covGrad);
