function noise = gaussianNoiseExpandParam(noise, params)

% GAUSSIANNOISEEXPANDPARAM Expand probit noise structure from param vector.
%
% noise = gaussianNoiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Tue Apr 20 22:59:02 2004
% IVM toolbox version 0.22



noise.bias = params(1:end-1);
noise.sigma2 = params(end);