function g = negIvmGradientNoise(params, model, prior)

% NEGIVMGRADIENTNOISE Wrapper function for calling noise param gradients.
%
% g = negIvmGradientNoise(params, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:46:18 2004
% IVM toolbox version 0.22



model.noise = noiseExpandParam(model.noise, params);
g = - noiseGradientParam(model.noise, model.mu, model.varSigma, model.y);

if prior
  g =g +params;
end