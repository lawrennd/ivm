function y = lnCumGaussian(x)

% LNCUMGAUSSIAN log cumulative distribution for Gaussian.
%
% y = lnCumGaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Apr 13 17:03:26 2004
% IVM toolbox version 0.22



index = find(x< 0);
if length(index)
  y(index) = -.5*x(index).*x(index) + log(.5) + log(erfcx(-sqrt(2)/2* ...
                                                    x(index)));
end
index = find(x>=0);
if length(index)
  y(index) = log(cumGaussian(x(index)));
end
y=reshape(y, size(x));