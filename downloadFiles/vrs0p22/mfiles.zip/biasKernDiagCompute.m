function k = biasKernDiagCompute(kern, x)

% BIASKERNDIAGCOMPUTE Compute diagonal of bias kernel.
%
% k = biasKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:31:05 2004
% IVM toolbox version 0.22



k = repmat(kern.variance, size(x, 1), 1);