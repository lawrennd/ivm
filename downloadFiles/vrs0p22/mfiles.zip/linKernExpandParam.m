function kern = linKernExpandParam(kern, params)

% LINKERNEXPANDPARAM Create kernel structure from linear kernel parameters.
%
% kern = linKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 00:25:33 2004
% IVM toolbox version 0.22


kern.variance = params(1);
