function kern = kernel(X, kernelType)

% KERNEL Initialise a kernel structure.
%
% kern = kernel(X, kernelType)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Mar  3 15:13:54 2004
% IVM toolbox version 0.22



kern.Kstore = [];
kern.diagK = [];
if iscell(kernelType)
  % compound kernel type
  kern.type = 'cmpnd';
  for i = 1:length(kernelType)
    kern.comp{i}.type = kernelType{i};
    kern.comp{i}.inputDimension = size(X, 2);
  end
else
  kern.type = kernelType;
  kern.inputDimension = size(X, 2);
end
kern = kernParamInit(kern);
