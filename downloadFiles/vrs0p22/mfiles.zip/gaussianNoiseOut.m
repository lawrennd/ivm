function y = gaussianNoiseOut(noise, mu, varsigma)

% GAUSSIANNOISEOUT Output from Gaussian noise model.
%
% y = gaussianNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri Mar 19 18:25:52 2004
% IVM toolbox version 0.22



D = size(mu, 2);
y = zeros(size(mu));
for i = 1:D
  y(:, i) = mu(:, i) + noise.bias(i);
end
