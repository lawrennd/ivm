function g = negNoiseGradientParam(params, model, prior)

% NEGNOISEGRADIENTPARAM Wrapper function for calling noise gradients.
%
% g = negNoiseGradientParam(params, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:46:48 2004
% IVM toolbox version 0.22



model.noise = noiseExpandParam(model.noise, params);
g = - feval([model.noise.type 'GradientParam'], model);

if prior
  g =g +params;
end