function gaussianNoiseDisplay(noise)

% GAUSSIANNOISEDISPLAY Display the parameters of the Gaussian noise model.
%
% gaussianNoiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 06:06:47 2004
% IVM toolbox version 0.22



for i = 1:noise.numProcess
  fprintf('Gaussian bias on process %d: %2.4f\n', i, noise.bias(i))
end
fprintf('Gaussian noise: %2.4f\n', noise.sigma2);