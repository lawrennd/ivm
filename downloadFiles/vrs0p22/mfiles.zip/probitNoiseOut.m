function y = probitNoiseOut(noise, mu, varsigma)

% PROBITNOISEOUT Output from probit noise model.
%
% y = probitNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Thu Apr  8 22:55:33 2004
% IVM toolbox version 0.22


D = size(mu, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
y = sign(mu);
