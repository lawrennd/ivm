function [params, names] = mgaussianNoiseExtractParam(noise)

% MGAUSSIANNOISEEXTRACTPARAM Extract parameters from Variable variance Gaussian noise model.
%
% [params, names] = mgaussianNoiseExtractParam(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri Apr 16 05:16:25 2004
% IVM toolbox version 0.22




params = [noise.bias noise.sigma2];


if nargout > 1
  for i = 1:noise.numProcess
    names{i} = ['bias ' num2str(i)];
  end
  for i = noise.numProcess+1:2*noise.numProcess
    names{i} = ['sigma^2 ' num2str(i)];
  end
end