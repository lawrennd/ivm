function params = linardKernExtractParam(kern)

% LINARDKERNEXTRACTPARAM Extract parameters from linear ARD kernel structure.
%
% params = linardKernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Fri Apr 16 02:45:58 2004
% IVM toolbox version 0.22



params = [kern.variance kern.inputScales];
