function k = whiteKernDiagCompute(kern, x)

% WHITEKERNDIAGCOMPUTE Compute diagonal of white noise kernel.
%
% k = whiteKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:30:55 2004
% IVM toolbox version 0.22



k = repmat(kern.variance, size(x, 1), 1);