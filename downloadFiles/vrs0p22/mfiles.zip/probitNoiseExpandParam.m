function noise = probitNoiseExpandParam(noise, params)

% PROBITNOISEEXPANDPARAM Expand probit noise structure from param vector.
%
% noise = probitNoiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:38:47 2004
% IVM toolbox version 0.22




noise.bias = params(1:end);

