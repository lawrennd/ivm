function kern = kernExpandParam(kern, params)

% KERNEXPANDPARAM Expand parameters to form a kernel structure.
%
% kern = kernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 01:10:41 2004
% IVM toolbox version 0.22



% Check if parameters are being optimised in a transformed space.
if isfield(kern, 'transforms')
  for i = 1:length(kern.transforms)
    index = kern.transforms(i).index;
    params(index) = feval([kern.transforms(i).type 'Transform'], ...
              params(index), 'atox');
  end
end

kern = feval([kern.type 'KernExpandParam'], kern, params);

