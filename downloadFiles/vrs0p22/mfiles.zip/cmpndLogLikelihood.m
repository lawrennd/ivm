function L = cmpndLogLikelihood(noise, mu, varsigma, y)

% CMPNDLOGLIKELIHOOD Log-likelihood of data under compound noise model.
%
% L = cmpndLogLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sun Mar 14 01:24:30 2004
% IVM toolbox version 0.22



L = 0;
for i = 1:length(noise.comp)
  L = L + feval([noise.comp{i}.type 'LogLikelihood'], ...
                noise.comp{i},...
                mu(:, i), ...
                varsigma(:, i), ...
                y(:, i));
end