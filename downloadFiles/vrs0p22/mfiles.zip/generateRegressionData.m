% GENERATEREGRESSIONDATA Tries to load a sampled data set otherwise generates it.
%
%
% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Apr 22 01:55:29 2004
% IVM toolbox version 0.22



try
  load regressionData.mat 
catch
  
  [void, errid] = lasterr;
  if strcmp(errid, '')
    randn('seed', 1e5)
    rand('seed', 1e5)
    numIn = 2;
    N = 500;
    X = zeros(N, numIn);
    X(1:floor(N/2), :) = ...
      randn(floor(N/2), numIn)*.5+1;
    X(floor(N/2)+1:end, :) = ...
	randn(ceil(N/2), numIn)*.5-1;
    kern = kernCreate(X, 'rbfard');
    kern.variance = 1;
    kern.inverseWidth = 20;
    kern.inputScales = [0 0.999];
    
    K = kernCompute(kern, X);
    y = real(gaussSamp(K, 1)') + randn(N, 1)*0.01;
  end

  save('regressionData.mat', 'numIn', 'N', 'X', 'y')
end
