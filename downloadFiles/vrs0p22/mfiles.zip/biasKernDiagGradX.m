function gX = biasKernDiagGradX(kern, x)

% BIASKERNDIAGGRADX Gradient of bias kernel's diagonal with respect to a point x.
%
% gX = biasKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:03:12 2004
% IVM toolbox version 0.22



gX = zeros(size(x));