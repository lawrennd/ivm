function params = ardKernExtractParam(kern)

% ARDKERNEXTRACTPARAM Extract parameters from ard kernel structure.
%
% params = ardKernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 02:38:24 2004
% IVM toolbox version 0.22



params = [kern.inverseWidth kern.rbfVariance ...
          kern.biasVariance kern.whiteVariance ...
          kern.linearVariance kern.inputScales];
