function y = sigmoid(x)

% SIGMOID The sigmoid function
%
% y = sigmoid(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Mar  3 15:13:59 2004
% IVM toolbox version 0.22



y = ones(size(x))./(1+exp(-x));