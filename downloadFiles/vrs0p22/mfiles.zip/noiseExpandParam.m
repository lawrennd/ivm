function noise = noiseExpandParam(noise, params)

% NOISEEXPANDPARAM Expand the noise model's parameters from params vector.
%
% noise = noiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 03:36:47 2004
% IVM toolbox version 0.22


if isfield(noise, 'transforms')
  for i = 1:length(noise.transforms)
    index = noise.transforms(i).index;
    params(index) = feval([noise.transforms(i).type 'Transform'], ...
              params(index), 'atox');
  end
end

noise = feval([noise.type 'NoiseExpandParam'], noise, params);
