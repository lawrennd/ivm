function kern = biasKernExpandParam(kern, params)

% BIASKERNEXPANDPARAM Create kernel structure from bias's parameters.
%
% kern = biasKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 01:16:14 2004
% IVM toolbox version 0.22



kern.variance = params(1);