function y = invCumGaussian(x)

% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
%
% y = invCumGaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Mar  3 15:13:52 2004
% IVM toolbox version 0.22



y = erfinv(x*2 - 1)*2/sqrt(2);