function g = linardKernGradient(kern, x, covGrad)

% LINARDKERNGRADIENT Gradient of linear ARD kernel's parameters.
%
% g = linardKernGradient(kern, x, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Fri Apr 16 02:46:22 2004
% IVM toolbox version 0.22


g = zeros(1, size(x, 2)+1);
k = linardKernCompute(kern, x);
g(1) = sum(sum(covGrad.*k))/kern.variance;
for i = 1:size(x, 2)
  g(1+i) =  x(:, i)'*covGrad*x(:, i)*kern.variance;
end