function kern = linardKernParamInit(kern)

% LINARDKERNPARAMINIT linear ARD kernel parameter initialisation.
%
% kern = linardKernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Fri Apr 16 02:45:11 2004
% IVM toolbox version 0.22



% This parameters is restricted positive.
kern.variance = 1;
% These parameters are restricted to lie between 0 and 1.
kern.inputScales = 0.999*ones(1, kern.inputDimension);
kern.nParams = 1 + kern.inputDimension;

kern.transforms(1).index = 1;
kern.transforms(1).type = 'negLogLogit';
kern.transforms(2).index = [2:kern.nParams];
kern.transforms(2).type = 'sigmoid';
