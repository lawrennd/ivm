function gX = linKernGradX(kern, x, X2)

% LINKERNGRADX Gradient of linear kernel with respect to a point X.
%
% gX = linKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:27:31 2004
% IVM toolbox version 0.22



gX = kern.variance.*X2;