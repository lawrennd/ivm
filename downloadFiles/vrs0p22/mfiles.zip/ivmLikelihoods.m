function L = ivmLikelihoods(model, x, y);

% IVMLOGLIKELIHOODS Return the likelihood for each point for the IVM.
%
% L = ivmLikelihoods(model, x, y);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Sun Mar 21 23:42:42 2004
% IVM toolbox version 0.22



if nargin < 3
  % This implies evaluate for the traing data.
  mu = model.mu;
  varsigma = model.varSigma;
  y = model.y;
else
  [mu, varsigma] = ivmPosteriorMeanVar(model, x);
end

L = noiseLikelihood(model.noise, mu, varsigma, y);
