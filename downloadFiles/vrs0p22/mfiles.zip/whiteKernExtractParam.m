function params = whiteKernExtractParam(kern)

% WHITEKERNEXTRACTPARAM Extract parameters from white noise kernel structure.
%
% params = whiteKernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 01:18:26 2004
% IVM toolbox version 0.22



params = kern.variance;
