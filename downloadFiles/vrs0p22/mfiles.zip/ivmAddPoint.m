function model = ivmAddPoint(model, i)

% IVMADDPOINT Add a point.
%
% model = ivmAddPoint(model, i)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Wed Apr 14 00:38:19 2004
% IVM toolbox version 0.22



index = find(model.J == i);
if isempty(index)
  error(['Point ' num2str(i) ' is not in inactive set'])
end

model = ivmUpdateSites(model, i);
if ~flag
  return
end
model = ivmUpdateM(model, i);

% Remove point from the non-active set and place in the active.
model.J(index) = [];
model.I = [model.I; i];

model = ivmUpdateNuG(model, model.J);
