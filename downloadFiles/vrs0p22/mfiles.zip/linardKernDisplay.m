function linardKernDisplay(kern)

% LINARDKERNDISPLAY Display parameters of linear ARD kernel.
%
% linardKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr 22 01:44:19 2004
% IVM toolbox version 0.22



fprintf('Linear ARD kernel Variance: %2.4f\n', kern.variance)
for i = 1:kern.inputDimension
  fprintf('Linear ARD Input %d scale: %2.4f\n', i, kern.inputScales(i))
end
