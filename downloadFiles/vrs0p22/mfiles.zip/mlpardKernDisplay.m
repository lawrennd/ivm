function mlpardKernDisplay(kern)

% MLPARDKERNDISPLAY Display parameters of multi-layer perceptron ARD kernel.
%
% mlpardKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr 22 01:43:56 2004
% IVM toolbox version 0.22



fprintf('MLP ARD kernel Variance: %2.4f\n', kern.variance)
fprintf('MLP ARD weight variance: %2.4f\n', kern.weightVariance)
fprintf('MLP ARD bias variance: %2.4f\n', kern.biasVariance)
for i = 1:kern.inputDimension
  fprintf('MLP ARD Input %d scale: %2.4f\n', i, kern.inputScales(i))
end
