function [params, transform] = sqexpKernExtractParam(kern)

% SQEXPKERNEXTRACTPARAM Extract parameters from squared exponential kernel structure.
%
% [params, transform] = sqexpKernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Fri Apr 16 03:27:28 2004
% IVM toolbox version 0.22



params = [kern.inverseWidth kern.rbfVariance kern.biasVariance ...
          kern.whiteVariance];

