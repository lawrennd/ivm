function y = cumGaussian(x)

% CUMGAUSSIAN Cumulative distribution for Gaussian.
%
% y = cumGaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Apr  8 19:11:46 2004
% IVM toolbox version 0.22



y = 0.5*(1+erf(sqrt(2)/2*x));
