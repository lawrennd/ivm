function   [indexSelect, infoChange] = ivmSelectPoint(model);

% IVMSELECTPOINT Choose a point for inclusion from the inactive set.
%
% [indexSelect, infoChange] = ivmSelectPoint(model);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sun Apr 11 04:26:33 2004
% IVM toolbox version 0.22



switch model.selectionCriterion
 case 'random'
  indexSelect = ceil(rand(1)*length(model.J));
  infoChange = -.5*log2(1-model.varSigma(indexSelect)*model.nu(indexSelect));
 case 'entropy' 
  delta = computeInfoChange(model);
  [infoChange, indexSelect] = max(delta);
  if sum(delta==infoChange)==length(delta);
    indexSelect = ceil(rand(1)*length(delta));
  end
end
