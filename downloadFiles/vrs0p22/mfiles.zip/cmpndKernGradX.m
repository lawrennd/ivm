function gX = cmpndKernGradX(kern, x, X2)

% CMPNDKERNGRADX Gradient of compound kernel with respect to a point x.
%
% gX = cmpndKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:28:09 2004
% IVM toolbox version 0.22



gX = kernGradX(kern.comp{1}, x, X2);
for i = 2:length(kern.comp)
  gX = gX + kernGradX(kern.comp{i}, x, X2);
end
