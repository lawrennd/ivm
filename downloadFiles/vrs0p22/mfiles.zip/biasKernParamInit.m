function kern = biasKernParamInit(kern)

% BIASKERNPARAMINIT bias kernel parameter initialisation.
%
% kern = biasKernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 01:15:26 2004
% IVM toolbox version 0.22



kern.variance = 1;
kern.nParams = 1;

kern.transforms.index = 1;
kern.transforms.type = 'negLogLogit';
