function params = mlpardKernExtractParam(kern)

% MLPARDKERNEXTRACTPARAM Extract parameters from multi-layer perceptron ARD kernel structure.
%
% params = mlpardKernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri Apr 16 01:13:12 2004
% IVM toolbox version 0.22



params = [kern.weightVariance kern.biasVariance kern.variance kern.inputScales];
