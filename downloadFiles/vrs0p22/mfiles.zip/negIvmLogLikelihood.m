function e = negIvmLogLikelihood(params, model, prior)

% NEGIVMLOGLIKELIHOOD Wrapper function for calling ivm likelihoods.
%
% e = negIvmLogLikelihood(params, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:46:32 2004
% IVM toolbox version 0.22



model.noise = noiseExpandParam(model.noise, params);
e = - ivmLogLikelihood(model);

if prior
  e =e +0.5*params*params';
end