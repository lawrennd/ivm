function L = noiseLogLikelihood(noise, mu, varsigma, y);

% NOISELOGLIKELIHOOD Return the log-likelihood under the noise model.
%
% L = noiseLogLikelihood(noise, mu, varsigma, y);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Sun Mar 21 23:44:48 2004
% IVM toolbox version 0.22



L = feval([noise.type 'LogLikelihood'], noise, mu, varsigma, y);
