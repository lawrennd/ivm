function k = rbfardKernDiagCompute(kern, x)

% RBFARDKERNDIAGCOMPUTE Compute diagonal of radial basis function ARD kernel.
%
% k = rbfardKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:30:33 2004
% IVM toolbox version 0.22




k = ones(size(x, 1), 1)*kern.variance;
