function mlpKernDisplay(kern)

% MLPKERNDISPLAY Display parameters of multi-layer perceptron kernel.
%
% mlpKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:40:01 2004
% IVM toolbox version 0.22



fprintf('MLP kernel Variance: %2.4f\n', kern.variance)
fprintf('MLP weight variance: %2.4f\n', kern.weightVariance)
fprintf('MLP bias variance: %2.4f\n', kern.biasVariance)