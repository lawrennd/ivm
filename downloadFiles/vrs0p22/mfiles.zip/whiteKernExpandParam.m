function kern = whiteKernExpandParam(kern, params)

% WHITEKERNEXPANDPARAM Create kernel structure from white noise's parameters.
%
% kern = whiteKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 01:15:40 2004
% IVM toolbox version 0.22



kern.variance = params(1);