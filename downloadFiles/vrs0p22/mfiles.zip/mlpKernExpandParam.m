function kern = mlpKernExpandParam(kern, params)

% MLPKERNEXPANDPARAM Create kernel structure from multi-layer perceptron's parameters.
%
% kern = mlpKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 00:13:56 2004
% IVM toolbox version 0.22



kern.weightVariance = params(1);
kern.biasVariance = params(2);
kern.variance = params(3);
