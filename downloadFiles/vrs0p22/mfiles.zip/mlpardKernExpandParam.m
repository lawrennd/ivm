function kern = mlpardKernExpandParam(kern, params)

% MLPARDKERNEXPANDPARAM Create kernel structure from multi-layer perceptron ARD's parameters.
%
% kern = mlpardKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri Apr 16 01:13:34 2004
% IVM toolbox version 0.22



kern.weightVariance = params(1);
kern.biasVariance = params(2);
kern.variance = params(3);
kern.inputScales = params(4:end);
