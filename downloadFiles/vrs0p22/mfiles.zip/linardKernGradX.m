function gX = linardKernGradX(kern, x, X2)

% LINARDKERNGRADX Gradient of linear ARD kernel with respect to a point x.
%
% gX = linardKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 16:43:02 2004
% IVM toolbox version 0.22



scales = sparse(diag(kern.inputScales));
X2 = X2*scales;

gX = kern.variance.*X2;