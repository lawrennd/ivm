function gX = whiteKernDiagGradX(kern, x)

% WHITEKERNDIAGGRADX Gradient of white noise kernel's diagonal with respect to a point x.
%
% gX = whiteKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:00:22 2004
% IVM toolbox version 0.22



gX = zeros(size(x));