function orderedNoiseDisplay(noise)

% ORDEREDNOISEDISPLAY Display the parameters of the ordered categorical noise model.
%
% orderedNoiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 06:06:38 2004
% IVM toolbox version 0.22



for i = 1:noise.numProcess
  fprintf('Ordered bias on process %d: %2.4f\n', i, noise.bias(i))
end
for i = 1:noise.C-2
  fprintf('Ordered noise model width %d: %2.4f\n', i, noise.widths(i))
end