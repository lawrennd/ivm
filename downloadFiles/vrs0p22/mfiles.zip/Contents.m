% IVM toolbox
% Version 0.22 Thursday, April 22, 2004 at 04:04:32
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.1 1.0 $
% 
% ARDKERNCOMPUTE Compute the kernel given the parameters and X.
% ARDKERNDIAGCOMPUTE Compute diagonal of ard kernel.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to a point x.
% ARDKERNDISPLAY Display parameters of ARD kernel.
% ARDKERNEXPANDPARAM Create kernel structure from ARD parameters.
% ARDKERNEXTRACTPARAM Extract parameters from ard kernel structure.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% ARDKERNGRADIENT Gradient of ard kernel's parameters.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% BIASKERNCOMPUTE Compute the bias kernel given the parameters and X.
% BIASKERNDIAGCOMPUTE Compute diagonal of bias kernel.
% BIASKERNDIAGGRADX Gradient of bias kernel's diagonal with respect to a point x.
% BIASKERNDISPLAY Display parameters of bias kernel.
% BIASKERNEXPANDPARAM Create kernel structure from bias's parameters.
% BIASKERNEXTRACTPARAM Extract parameters from bias kernel structure.
% BIASKERNGRADX Gradient of bias kernel with respect to a point x.
% BIASKERNGRADIENT Gradient of bias kernel's parameters.
% BIASKERNPARAMINIT bias kernel parameter initialisation.
% CMPNDKERNCOMPUTE Compute the kernel given the parameters and X.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of compound kernel.
% CMPNDKERNDIAGGRADX Gradient of compound kernel's diagonal with respect to a point x.
% CMPNDKERNDISPLAY Display the parameters of the compound kernel.
% CMPNDKERNEXPANDPARAM Create kernel structure from ARD parameters.
% CMPNDKERNEXTRACTPARAM Extract parameters from compound kernel structure.
% CMPNDKERNGRADX Gradient of compound kernel with respect to a point x.
% CMPNDKERNGRADIENT Gradient of compound kernel's parameters.
% CMPNDKERNPARAMINIT Compound kernel parameter initialisation.
% CMPNDLIKELIHOOD Likelihood of data under compound noise model.
% CMPNDLOGLIKELIHOOD Log-likelihood of data under compound noise model.
% CMPNDNOISEDISPLAY Display the parameters of the compound noise model.
% CMPNDNOISEEXPANDPARAM Expand probit noise structure from param vector.
% CMPNDNOISEEXTRACTPARAM Extract parameters from compound noise model.
% CMPNDNOISEGRADVALS Gradient wrt x of log-likelihood for compound noise model.
% CMPNDNOISEGRADIENTPARAM Gradient of the compound noise model's parameters.
% CMPNDNOISEOUT Output from compound noise model.
% CMPNDNOISEPARAMINIT Compound noise model's parameter initialisation.
% CMPNDTIEPARAMETERS Tie parameters together.
% COMPUTEINFOCHANGE Compute the information change associated with each point.
% COVARINCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
% CUMGAUSSIAN Cumulative distribution for Gaussian.
% DEMCLASSIFICATION1 Test IVM code on a toy feature selection
% DEMCLASSIFICATION2 IVM for classification on a data-set sampled from a GP.
% DEMORDERED1 Run a demonstration of the ordered categories noise model.
% DEMREGRESSION1 The data-set is sampled from a GP with known parameters.
% EXPTRANSFORM Constrains a parameter to be positive through exponentiation.
% GAUSSOVERDIFFCUMGAUSSIAN A gaussian in x over the difference between two cumulative Gaussians. 
% GAUSSIANLIKELIHOOD Likelihood of data under Gaussian noise model.
% GAUSSIANLOGLIKELIHOOD Log-likelihood of data under Gaussian noise model.
% GAUSSIANNOISEDISPLAY Display the parameters of the Gaussian noise model.
% GAUSSIANNOISEEXPANDPARAM Expand probit noise structure from param vector.
% GAUSSIANNOISEEXTRACTPARAM Extract parameters from Gaussian noise model.
% GAUSSIANNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for gaussian noise model.
% GAUSSIANNOISEGRADIENTPARAM Gradient of the Gaussian noise model's parameters.
% GAUSSIANNOISEOUT Output from Gaussian noise model.
% GAUSSIANNOISEPARAMINIT Gaussian noise model's parameter initialisation.
% GENERATECLASSIFICATIONDATA Tries to load a sampled data set otherwise generates it.
% GENERATEREGRESSIONDATA Tries to load a sampled data set otherwise generates it.
% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
% LINEARBOUND Constrains a parameter to be positive.
% INVSIGMOID The inverse of the sigmoid function.
% IVM Initialise an IVM model.
% IVMADDPOINT Add a point.
% IVMSAVE break IVM in pieces for saving.
% IVMDISPLAY Display parameters of ivm model.
% IVMINIT Initialise the IVM model.
% IVMLOGLIKELIHOODS Return the likelihood for each point for the IVM.
% IVMLOGLIKELIHOOD Return the log-likelihood for the IVM.
% IVMOPTIMISE Optimise the IVM.
% IVMOPTIMISEIVM Optimises an IVM model.
% IVMOPTIMISEKERNEL Optimise the kernel parameters.
% IVMOPTIMISENOISE Optimise the noise parameters.
% IVMOUT Evaluate the output of an ivm model.
% IVMPOSTERIORGRADMEANVAR Gradient of mean and variances of the posterior wrt X.
% IVMPOSTERIORMEANVAR Mean and variances of the posterior at points given b X.
% IVMLOAD Load an IVM structure.
% IVMRUN Run ivm on a data set.
% IVMSELECTPOINT Choose a point for inclusion from the inactive set.
% IVMUPDATEM Update matrix M, L, v and mu.
% IVMUPDATENUG Update nu and g parameters associated with noise model.
% IVMUPDATESITES Update site parameters.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% KERNCREATE Initialise a kernel structure.
% KERNELCOMPUTE Compute the kernel given the parameters and X.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% KERNDISPLAY Display the parameters of the kernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% KERNGRADX Compute the gradient of the  kernel wrt X.
% KERNGRADIENT Compute the gradient of the kernel's parameters.
% KERNPARAMINIT Kernel parameter initialisation.
% KERNTEST Run some tests on the specified kernel.
% KERNEL Initialise a kernel structure.
% KERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
% KERNELOBJECTIVE Likelihood approximation.
% LINKERNCOMPUTE Compute the kernel given the parameters and X.
% LINKERNDIAGCOMPUTE Compute diagonal of linear kernel.
% LINKERNDIAGGRADX Gradient of linear kernel's diagonal with respect to a point x.
% LINKERNDISPLAY Display parameters of linear kernel.
% LINKERNEXPANDPARAM Create kernel structure from linear kernel parameters.
% LINKERNEXTRACTPARAM Extract parameters from linear kernel structure.
% LINKERNGRADX Gradient of linear kernel with respect to a point X.
% LINKERNGRADIENT Gradient of lin kernel's parameters.
% LINKERNPARAMINIT Linear kernel parameter initialisation.
% LINARDKERNCOMPUTE Compute the linear ARD kernel given the parameters and X.
% LINARDKERNDIAGCOMPUTE Compute diagonal of linear ARD kernel.
% LINARDKERNDIAGGRADX Gradient of linear ARD kernel's diagonal with respect to a point x.
% LINARDKERNDISPLAY Display parameters of linear ARD kernel.
% LINARDKERNEXPANDPARAM Create kernel structure from linear ARD's parameters.
% LINARDKERNEXTRACTPARAM Extract parameters from linear ARD kernel structure.
% LINARDKERNGRADX Gradient of linear ARD kernel with respect to a point x.
% LINARDKERNGRADIENT Gradient of linear ARD kernel's parameters.
% LINARDKERNPARAMINIT linear ARD kernel parameter initialisation.
% LNCUMGAUSSIAN log cumulative distribution for Gaussian.
% LOGDET The log of the determinant when argument is positive definite.
% MGAUSSIANLIKELIHOOD Likelihood of data under Variable variance Gaussian noise model.
% MGAUSSIANLOGLIKELIHOOD Log-likelihood of data under Variable variance Gaussian noise model.
% MGAUSSIANNOISEDISPLAY Display  parameters from Variable variance Gaussian noise model.
% MGAUSSIANNOISEEXPANDPARAM Expand Variable variance Gaussian noise model's structure from param vector.
% MGAUSSIANNOISEEXTRACTPARAM Extract parameters from Variable variance Gaussian noise model.
% MGAUSSIANNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for Variable variance Gaussian noise model.
% MGAUSSIANNOISEGRADIENTPARAM Gradient of the Variable variance Gaussian noise model's parameters.
% MGAUSSIANNOISEOUT Ouput from Variable variance Gaussian noise model.
% MGAUSSIANNOISEPARAMINIT Variable variance Gaussian noise model's parameter initialisation.
% MLPKERNCOMPUTE Compute the multi-layer perceptron kernel given the parameters and X.
% MLPKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron kernel.
% MLPKERNDIAGGRADX Gradient of  multi-layer perceptron kernel's diagonal with respect to a point x.
% MLPKERNDISPLAY Display parameters of multi-layer perceptron kernel.
% MLPKERNEXPANDPARAM Create kernel structure from multi-layer perceptron's parameters.
% MLPKERNEXTRACTPARAM Extract parameters from multi-layer perceptron kernel structure.
% MLPKERNGRADX Gradient of multi-layer perceptron kernel with respect to a point X.
% MLPKERNGRADIENT Gradient of multi-layer perceptron kernel's parameters.
% MLPKERNPARAMINIT multi-layer perceptron kernel parameter initialisation.
% MLPARDKERNCOMPUTE Compute the multi-layer perceptron ARD kernel given the parameters and X.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron ARD kernel.
% MLPARDKERNDIAGGRADX Gradient of multi-layer perceptron ARD kernel's diagonal with respect to a point x.
% MLPARDKERNDISPLAY Display parameters of multi-layer perceptron ARD kernel.
% MLPARDKERNEXPANDPARAM Create kernel structure from multi-layer perceptron ARD's parameters.
% MLPARDKERNEXTRACTPARAM Extract parameters from multi-layer perceptron ARD kernel structure.
% MLPARDKERNGRADX Gradient of multi-layer perceptron ARD kernel with respect to a point x.
% MLPARDKERNGRADIENT Gradient of multi-layer perceptron ARD kernel's parameters.
% MLPARDKERNPARAMINIT multi-layer perceptron ARD kernel parameter initialisation.
% NEGIVMGRADIENTNOISE Wrapper function for calling noise param gradients.
% NEGIVMLOGLIKELIHOOD Wrapper function for calling ivm likelihoods.
% NEGLOGLOGIT Constrains a parameter to be positive.
% NEGNOISEGRADIENTPARAM Wrapper function for calling noise gradients.
% NEGNOISELOGLIKELIHOOD Wrapper function for calling noise likelihoods.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% NOISECREATE Initialise a noise structure.
% NOISEDISPLAY Display the parameters of the noise model.
% NOISEEXPANDPARAM Expand the noise model's parameters from params vector.
% NOISEEXTRACTPARAM Extract the noise model's parameters.
% NOISEGRADVALS Gradient of noise model wrt mu and varsigma.
% NOISEGRADIENTPARAM Gradient of the noise model's parameters.
% NOISELIKELIHOOD Return the likelihood for each point under the noise model.
% NOISELOGLIKELIHOOD Return the log-likelihood under the noise model.
% NOISEOUT Give the output of the noise model given the mean and variance.
% NOISEPARAMINIT Noise model's parameter initialisation.
% NOISETEST Run some tests on the specified noise model.
% OPTIMISEPARAMS Optimise parameters.
% ORDEREDLIKELIHOOD Likelihood of data under ordered categorical noise model.
% ORDEREDLOGLIKELIHOOD Log-likelihood of data under ordered categorical noise model.
% ORDEREDNOISEDISPLAY Display the parameters of the ordered categorical noise model.
% ORDEREDNOISEEXPANDPARAM Expand ordered categorical noise model's structure from param vector.
% ORDEREDNOISEEXTRACTPARAM Extract parameters from ordered categorical noise model.
% ORDEREDNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for ordered categorical noise model.
% ORDEREDNOISEGRADIENTPARAM Gradient of the ordered categorical noise model's parameters.
% ORDEREDNOISEOUT Output from ordered categorical noise model.
% ORDEREDNOISEPARAMINIT Ordered categorical noise model's parameter initialisation.
% PDINV Computes the inverse of a positive definite matrix
% PROBITLIKELIHOOD Likelihood of data under probit noise model.
% PROBITLOGLIKELIHOOD Log-likelihood of data under probit noise model.
% PROBITNOISEDISPLAY Display the parameters of the Probit noise model.
% PROBITNOISEEXPANDPARAM Expand probit noise structure from param vector.
% PROBITNOISEEXTRACTPARAM Extract parameters from probit noise model.
% PROBITNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for probit noise model.
% PROBITNOISEGRADIENTPARAM Gradient of the probit noise model's parameters.
% PROBITNOISEOUT Output from probit noise model.
% PROBITNOISEPARAMINIT probistic classification model's parameter initialisation.
% RBFKERNCOMPUTE Compute the kernel given the parameters and X.
% RBFKERNDIAGCOMPUTE Compute diagonal of rbf kernel.
% RBFKERNDIAGGRADX Gradient of Radial basis function kernel's diagonal with respect to a point x.
% RBFKERNDISPLAY Display parameters of radial basis function kernel.
% RBFKERNEXPANDPARAM Create kernel structure from rbf parameters.
% RBFKERNEXTRACTPARAM Extract parameters from rbf kernel structure.
% RBFKERNGRADX Gradient of Radial basis function kernel with respect to a point X.
% RBFKERNGRADIENT Gradient of rbf kernel's parameters.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% RBFARDKERNCOMPUTE Compute the radial basis function ARD kernel given the parameters and X.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of radial basis function ARD kernel.
% RBFARDKERNDIAGGRADX Gradient of radial basis function ARD kernel's diagonal with respect to a point x.
% RBFARDKERNDISPLAY Display parameters of radial basis function ARD kernel.
% RBFARDKERNEXPANDPARAM Create kernel structure from radial basis function ARD's parameters.
% RBFARDKERNEXTRACTPARAM Extract parameters from radial basis function ARD kernel structure.
% RBFARDKERNGRADX Gradient of radial basis function ARD kernel with respect to a point x.
% RBFARDKERNGRADIENT Gradient of radial basis function ARD kernel's parameters.
% RBFARDKERNPARAMINIT radial basis function ARD kernel parameter initialisation.
% SIGMOID The sigmoid function
% SIGMOIDTRANSFORM Constrains a parameter to be between 0 and 1.
% SQEXPKERNCOMPUTE Compute the squared exponential kernel given the parameters and X.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of squared exponential kernel.
% SQEXPKERNDIAGGRADX Gradient of squared exponential kernel's diagonal with respect to a point x.
% SQEXPKERNDISPLAY Display parameters of squared exponential kernel.
% SQEXPKERNEXPANDPARAM Create kernel structure from squared exponential's parameters.
% SQEXPKERNEXTRACTPARAM Extract parameters from squared exponential kernel structure.
% SQEXPKERNGRADX Gradient of squared exponential kernel with respect to a point X.
% SQEXPKERNGRADIENT Gradient of squared exponential kernel's parameters.
% SQEXPKERNPARAMINIT squared exponential kernel parameter initialisation.
% WHITEKERNCOMPUTE Compute the white noise kernel given the parameters and X.
% WHITEKERNDIAGCOMPUTE Compute diagonal of white noise kernel.
% WHITEKERNDIAGGRADX Gradient of white noise kernel's diagonal with respect to a point x.
% WHITEKERNDISPLAY Display parameters of white noise kernel.
% WHITEKERNEXPANDPARAM Create kernel structure from white noise's parameters.
% WHITEKERNEXTRACTPARAM Extract parameters from white noise kernel structure.
% WHITEKERNGRADX Gradient of white noise kernel with respect to a point x.
% WHITEKERNGRADIENT Gradient of white noise kernel's parameters.
% WHITEKERNPARAMINIT white noise kernel parameter initialisation.
