function gX = ardKernDiagGradX(kern, x)

% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to a point x.
%
% gX = ardKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 04:57:29 2004
% IVM toolbox version 0.22




gX = 2*kern.linearVariance*x.*kern.inputScales;

