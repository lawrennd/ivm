function k = kernDiagCompute(kern, x, x2)

% KERNELCOMPUTE Compute the kernel given the parameters and X.
%
% k = kernDiagCompute(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:02:43 2004
% IVM toolbox version 0.22



if nargin < 3
  k = feval([kern.type 'KernDiagCompute'], kern, x);
else
  k = feval([kern.type 'KernDiagCompute'], kern, x, x2);
end
