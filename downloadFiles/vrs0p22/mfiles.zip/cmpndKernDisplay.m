function cmpndKernDisplay(kern)

% CMPNDKERNDISPLAY Display the parameters of the compound kernel.
%
% cmpndKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:42:08 2004
% IVM toolbox version 0.22



for i = 1:length(kern.comp)
  kernDisplay(kern.comp{i});
end