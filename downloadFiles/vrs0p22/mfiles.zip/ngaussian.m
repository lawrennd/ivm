function y = ngaussian(x)

% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
%
% y = ngaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Mar  3 15:13:56 2004
% IVM toolbox version 0.22



x2 = x.*x;
y = exp(-.5*x2);
y = y/sqrt(2*pi);
