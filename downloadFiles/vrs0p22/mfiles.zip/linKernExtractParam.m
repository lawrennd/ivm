function params = linKernExtractParam(kern)

% LINKERNEXTRACTPARAM Extract parameters from linear kernel structure.
%
% params = linKernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 00:25:50 2004
% IVM toolbox version 0.22



params = kern.variance;
