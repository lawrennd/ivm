function k = kernDiagGradX(kern, x, x2)

% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
%
% k = kernDiagGradX(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:02:19 2004
% IVM toolbox version 0.22



if nargin < 3
  k = feval([kern.type 'KernDiagGradX'], kern, x);
else
  k = feval([kern.type 'KernDiagGradX'], kern, x, x2);
end
