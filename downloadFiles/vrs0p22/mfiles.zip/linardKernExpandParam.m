function kern = linardKernExpandParam(kern, params)

% LINARDKERNEXPANDPARAM Create kernel structure from linear ARD's parameters.
%
% kern = linardKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Fri Apr 16 02:45:35 2004
% IVM toolbox version 0.22



kern.variance = params(1);
kern.inputScales = params(2:end);
