function model = ivmOptimiseNoise(model, prior, display, iters);

% IVMOPTIMISENOISE Optimise the noise parameters.
%
% model = ivmOptimiseNoise(model, prior, display, iters);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Mar 13 02:43:53 2004
% IVM toolbox version 0.22



if nargin < 4
  iters = 500;
  if nargin < 3
    display = 1;
    if nargin < 2
      prior = 0;
    end
  end
end
options = foptions;
if display
  options(1) = 1;
end
options(14) = iters;

model = optimiseParams('noise', 'scg', 'negIvmLogLikelihood', ...
                       'negIvmGradientNoise', options, model, prior);
