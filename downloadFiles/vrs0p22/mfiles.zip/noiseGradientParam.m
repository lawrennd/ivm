function g = noiseGradientParam(noise, mu, varsigma, y)

% NOISEGRADIENTPARAM Gradient of the noise model's parameters.
%
% g = noiseGradientParam(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Fri Apr 16 03:35:37 2004
% IVM toolbox version 0.22



g = feval([noise.type 'NoiseGradientParam'], noise, mu, varsigma, y);


% Check if parameters are being optimised in a transformed space.
if isfield(noise, 'transforms')
  params = feval([noise.type 'NoiseExtractParam'], noise);
  for i = 1:length(noise.transforms)
    index = noise.transforms(i).index;
    g(index) = g(index).* ...
        feval([noise.transforms(i).type 'Transform'], ...
              params(index), 'gradfact');
  end
end