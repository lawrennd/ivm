function y = invLinearBound(x)

% LINEARBOUND Constrains a parameter to be positive.
%
% y = invLinearBound(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Apr 13 15:01:43 2004
% IVM toolbox version 0.22



limVal = 36;
index = find(x<-limVal);
y(index) = eps;
x(index) = NaN;
index = find(x<limVal);
y(index) = log(1+exp(x(index)));
x(index) = NaN;
index = find(~isnan(x));
y(index) = x(index);
