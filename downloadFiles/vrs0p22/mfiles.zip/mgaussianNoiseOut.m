function y = mgaussianNoiseOut(noise, mu, varsigma)

% MGAUSSIANNOISEOUT Ouput from Variable variance Gaussian noise model.
%
% y = mgaussianNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Apr 13 01:45:16 2004
% IVM toolbox version 0.22



D = size(mu, 2);
y = zeros(size(mu));
for i = 1:D
  y(:, i) = mu(:, i) + noise.bias(i);
end

