function params = biasKernExtractParam(kern)

% BIASKERNEXTRACTPARAM Extract parameters from bias kernel structure.
%
% params = biasKernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 01:18:53 2004
% IVM toolbox version 0.22



params = kern.variance;
