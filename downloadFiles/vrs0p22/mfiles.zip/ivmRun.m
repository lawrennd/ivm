function model = ivmRun(XTrain, yTrain, kernelType, noiseType, ...
			selectionCriterion, dVal, prior, display, innerIters, ...
			   outerIters, tieStructure)

% IVMRUN Run ivm on a data set.
%
% model = ivmRun(XTrain, yTrain, kernelType, noiseType, ...
% 			selectionCriterion, dVal, prior, display, innerIters, ...
% 			   outerIters, tieStructure)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue Apr  6 16:59:18 2004
% IVM toolbox version 0.22



% Intitalise IVM
model = ivm(XTrain, yTrain, kernelType, noiseType, selectionCriterion, dVal);

if nargin > 10
  % Some of the kernel parameters are constrained to equal each other.
  model.kern = cmpndTieParameters(model.kern, tieStructure);
end

% Find the kernel parameters
model = ivmOptimise(model, prior, display, innerIters, outerIters);

% Select data-points in an IVM with those kernel parameters.
model = ivmOptimiseIVM(model, display);
