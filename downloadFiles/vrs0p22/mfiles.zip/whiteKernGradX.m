function gX = whiteKernGradX(kern, x, X2)

% WHITEKERNGRADX Gradient of white noise kernel with respect to a point x.
%
% gX = whiteKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:27:20 2004
% IVM toolbox version 0.22



gX = zeros(size(X2));