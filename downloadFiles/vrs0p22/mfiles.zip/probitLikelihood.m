function L = probitLikelihood(noise, mu, varsigma, y)

% PROBITLIKELIHOOD Likelihood of data under probit noise model.
%
% L = probitLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Mar 13 02:55:54 2004
% IVM toolbox version 0.22


D = size(y, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
L = cumGaussian((y.*mu)./(sqrt(1+varsigma)));
