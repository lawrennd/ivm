function rbfardKernDisplay(kern)

% RBFARDKERNDISPLAY Display parameters of radial basis function ARD kernel.
%
% rbfardKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:49:39 2004
% IVM toolbox version 0.22



fprintf('RBF ARD Variance: %2.4f\n', kern.variance)
fprintf('RBF ARD inverse width: %2.4f\n', kern.inverseWidth)
for i = 1:kern.inputDimension
  fprintf('RBF ARD Input %d scale: %2.4f\n', i, kern.inputScales(i))
end
