function k = linardKernDiagCompute(kern, x)

% LINARDKERNDIAGCOMPUTE Compute diagonal of linear ARD kernel.
%
% k = linardKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:30:20 2004
% IVM toolbox version 0.22



scales = sparse(diag(sqrt(kern.inputScales)));
x = x*scales;

k = sum(x.*x, 2)*kern.variance;
