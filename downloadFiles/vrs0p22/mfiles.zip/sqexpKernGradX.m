function gX = sqexpKernGradX(kern, x, x2)

% SQEXPKERNGRADX Gradient of squared exponential kernel with respect to a point X.
%
% gX = sqexpKernGradX(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:02:00 2004
% IVM toolbox version 0.22



gX = zeros(size(x2));
n2 = dist2(x2, x);
wi2 = (.5 .* kern.inverseWidth);
rbfPart = kern.rbfVariance*exp(-n2*wi2);
for i = 1:size(x, 2)
  gX(:, i) = kern.inverseWidth*(x2(:, i) - x(i)).*rbfPart;
end
