function y=invsigmoid(x)

% INVSIGMOID The inverse of the sigmoid function.
%
% y=invsigmoid(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Mar  3 15:13:52 2004
% IVM toolbox version 0.22



y = log(x./(1-x));