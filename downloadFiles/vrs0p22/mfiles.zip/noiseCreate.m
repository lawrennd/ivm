function noise = noiseCreate(noiseType, y)

% NOISECREATE Initialise a noise structure.
%
% noise = noiseCreate(noiseType, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Mar 19 19:00:51 2004
% IVM toolbox version 0.22



if iscell(noiseType)
  % compound noise type
  noise.type = 'cmpnd';
  for i = 1:length(noiseType)
    noise.comp{i}.type = noiseType{i};
  end
else
  noise.type = noiseType;
end

noise = noiseParamInit(noise, y);
