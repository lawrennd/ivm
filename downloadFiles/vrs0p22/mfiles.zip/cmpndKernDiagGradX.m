function gX = cmpndKernDiagGradX(kern, x)

% CMPNDKERNDIAGGRADX Gradient of compound kernel's diagonal with respect to a point x.
%
% gX = cmpndKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:04:06 2004
% IVM toolbox version 0.22



gX = kernDiagGradX(kern.comp{1}, x);
for i = 2:length(kern.comp)
  gX = gX + kernDiagGradX(kern.comp{i}, x);
end
