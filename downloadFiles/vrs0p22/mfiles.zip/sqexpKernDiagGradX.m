function gX = sqexpKernDiagGradX(kern, x)

% SQEXPKERNDIAGGRADX Gradient of squared exponential kernel's diagonal with respect to a point x.
%
% gX = sqexpKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:00:59 2004
% IVM toolbox version 0.22



gX = zeros(size(x));
