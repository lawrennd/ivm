function L = probitLogLikelihood(noise, mu, varsigma, y)

% PROBITLOGLIKELIHOOD Log-likelihood of data under probit noise model.
%
% L = probitLogLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Apr  8 22:48:11 2004
% IVM toolbox version 0.22



D = size(y, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
L = sum(sum(lnCumGaussian((y.*mu)./(sqrt(1+varsigma)))));
