function k = cmpndKernDiagCompute(kern, x)

% CMPNDKERNDIAGCOMPUTE Compute diagonal of compound kernel.
%
% k = cmpndKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:03:34 2004
% IVM toolbox version 0.22


k = kernDiagCompute(kern.comp{1}, x);
for i = 2:length(kern.comp)
  k  = k + kernDiagCompute(kern.comp{i}, x);
end
