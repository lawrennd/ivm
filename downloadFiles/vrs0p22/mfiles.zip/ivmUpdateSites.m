function model = ivmUpdateSites(model, index)

% IVMUPDATESITES Update site parameters.
%
% model = ivmUpdateSites(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Mon Apr 12 16:36:09 2004
% IVM toolbox version 0.22


  
model.beta(index, :) = model.nu(index, :) ...
    ./(1 - model.nu(index, :).*model.varSigma(index, :));
model.m(index, :) = model.mu(index, :) + model.g(index, :)./model.nu(index, :);

if any(model.beta<0)
  warning('Beta less than zero')
end
