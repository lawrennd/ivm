function kern = rbfKernParamInit(kern)

% RBFKERNPARAMINIT RBF kernel parameter initialisation.
%
% kern = rbfKernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 00:20:12 2004
% IVM toolbox version 0.22



kern.inverseWidth = 1;
kern.variance = 1;
kern.nParams = 2;

kern.transforms.index = [1 2];
kern.transforms.type = 'negLogLogit';
