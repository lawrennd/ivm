function whiteKernDisplay(kern)

% WHITEKERNDISPLAY Display parameters of white noise kernel.
%
% whiteKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:36:28 2004
% IVM toolbox version 0.22



fprintf('White Noise Variance: %2.4f\n', kern.variance)
