function kern = rbfKernExpandParam(kern, params)

% RBFKERNEXPANDPARAM Create kernel structure from rbf parameters.
%
% kern = rbfKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Apr 16 00:20:29 2004
% IVM toolbox version 0.22



kern.inverseWidth = params(1);
kern.variance = params(2);
