function k = mlpardKernDiagCompute(kern, x)

% MLPARDKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron ARD kernel.
%
% k = mlpardKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sun Apr 11 23:17:33 2004
% IVM toolbox version 0.22



scales = sparse(diag(sqrt(kern.inputScales)));
x = x*scales;
numer = sum(x.*x, 2)*kern.weightVariance + kern.biasVariance;
denom = numer+1;
k = kern.variance*asin(numer./denom);
