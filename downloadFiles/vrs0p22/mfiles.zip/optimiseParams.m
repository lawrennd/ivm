function model = optimiseParams(component, optimiser, objective, ...
                                gradient, options, model, prior);

% OPTIMISEPARAMS Optimise parameters.
%
% model = optimiseParams(component, optimiser, objective, ...
%                                 gradient, options, model, prior);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Sun Apr 11 04:48:39 2004
% IVM toolbox version 0.22



if nargin < 5
  prior = 0;
end


params = feval([component 'ExtractParam'], getfield(model, component));

if options(1)
  if length(params) > 20
    options(9) = 0;
  else
    options(9) = 1;
  end
end

params = feval(optimiser, objective, params, options, gradient, model, prior);

model = setfield(model, ...
                 component, ...
                 feval([component 'ExpandParam'], ...
                       getfield(model, component), ...
                       params));
