function L = noiseLikelihood(noise, mu, varsigma, y);

% NOISELIKELIHOOD Return the likelihood for each point under the noise model.
%
% L = noiseLikelihood(noise, mu, varsigma, y);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Mar 21 23:43:23 2004
% IVM toolbox version 0.22



L = feval([noise.type 'Likelihood'], noise, mu, varsigma, y);
