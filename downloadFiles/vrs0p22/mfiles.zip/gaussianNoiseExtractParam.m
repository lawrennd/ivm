function [params, names] = gaussianNoiseExtractParam(noise)

% GAUSSIANNOISEEXTRACTPARAM Extract parameters from Gaussian noise model.
%
% [params, names] = gaussianNoiseExtractParam(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Tue Apr 20 22:59:05 2004
% IVM toolbox version 0.22



params = [noise.bias noise.sigma2];


if nargout > 1
  for i = 1:noise.numProcess
    names{i} = ['bias ' num2str(i)];
  end
  names{i+1} = ['sigma^2 ' num2str(i)];
end