function gX = mlpKernDiagGradX(kern, x)

% MLPKERNDIAGGRADX Gradient of  multi-layer perceptron kernel's diagonal with respect to a point x.
%
% gX = mlpKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sun Apr 11 23:04:49 2004
% IVM toolbox version 0.22



innerProd = x*x';  
numer = innerProd*kern.weightVariance + kern.biasVariance;
denom = numer + 1;
arg = numer./denom;
gX = zeros(size(x));
for j = 1:size(x, 2)
  gX(:, j)=1./denom...
           - numer./denom.^2;
  gX(:, j) = 2*x(:, j)*kern.weightVariance*kern.variance*gX(:, j)./sqrt(1-arg.*arg);
end
