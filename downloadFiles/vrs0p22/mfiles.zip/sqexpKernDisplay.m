function sqexpKernDisplay(kern)

% SQEXPKERNDISPLAY Display parameters of squared exponential kernel.
%
% sqexpKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Apr 20 22:17:23 2004
% IVM toolbox version 0.22



fprintf('RBF Variance: %2.4f\n', kern.rbfVariance)
fprintf('RBF inverse width: %2.4f\n', kern.inverseWidth)
fprintf('White noise Variance: %2.4f\n', kern.whiteVariance)
fprintf('Bias Kernel Variance: %2.4f\n', kern.biasVariance)
