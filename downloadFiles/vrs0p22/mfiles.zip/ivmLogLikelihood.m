function L = ivmLogLikelihood(model, x, y);

% IVMLOGLIKELIHOOD Return the log-likelihood for the IVM.
%
% L = ivmLogLikelihood(model, x, y);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Sun Mar 21 23:44:35 2004
% IVM toolbox version 0.22



if nargin < 3
  % This implies evaluate for the traing data.
  mu = model.mu;
  varsigma = model.varSigma;
  y = model.y;
else
  [mu, varsigma] = ivmPosteriorMeanVar(model, x);
end

L = noiseLogLikelihood(model.noise, mu, varsigma, y);
