function gX = linKernDiagGradX(kern, x)

% LINKERNDIAGGRADX Gradient of linear kernel's diagonal with respect to a point x.
%
% gX = linKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 04:01:04 2004
% IVM toolbox version 0.22



gX = 2*x*kern.variance;
