function rbfKernDisplay(kern)

% RBFKERNDISPLAY Display parameters of radial basis function kernel.
%
% rbfKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:32:54 2004
% IVM toolbox version 0.22



fprintf('RBF Variance: %2.4f\n', kern.variance)
fprintf('RBF inverse width: %2.4f\n', kern.inverseWidth)
