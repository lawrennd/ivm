function noiseDisplay(noise)

% NOISEDISPLAY Display the parameters of the noise model.
%
% noiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:51:38 2004
% IVM toolbox version 0.22



feval([noise.type 'NoiseDisplay'], noise)