function linKernDisplay(kern)

% LINKERNDISPLAY Display parameters of linear kernel.
%
% linKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:35:47 2004
% IVM toolbox version 0.22



fprintf('Linear kernel Variance: %2.4f\n', kern.variance)
