function y = noiseOut(noise, mu, varsigma);

% NOISEOUT Give the output of the noise model given the mean and variance.
%
% y = noiseOut(noise, mu, varsigma);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri Mar 19 18:26:35 2004
% IVM toolbox version 0.22



y = feval([noise.type 'NoiseOut'], noise, mu, varsigma);