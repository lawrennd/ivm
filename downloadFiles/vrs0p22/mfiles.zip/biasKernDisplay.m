function biasKernDisplay(kern)

% BIASKERNDISPLAY Display parameters of bias kernel.
%
% biasKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr 12 05:36:54 2004
% IVM toolbox version 0.22



fprintf('Bias Variance: %2.4f\n', kern.variance)
