function gX = biasKernGradX(kern, x, X2)

% BIASKERNGRADX Gradient of bias kernel with respect to a point x.
%
% gX = biasKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sun Apr 11 03:27:17 2004
% IVM toolbox version 0.22



gX = zeros(size(X2));