% DEMCLASSIFICATION3 IVM for classification on a data-set sampled from a GP.
%
% 

% Copyright (c) 2005 Neil D. Lawrence
% demClassification3.m version 



% Sample a classification data-set.

randn('seed', 1e5)
rand('seed', 1e5)
[X, y ] = ivmLoadData('classificationThree');
noiseModel = 'probit';
selectionCriterion = 'entropy';
kernelType = {'rbf', 'white'};

options = ivmOptions;
options.display = 2;
dVal = 100;
% Initialise the IVM.
model = ivm(X, y, kernelType, noiseModel, selectionCriterion, dVal);
if options.display > 1
  ivm3dPlot(model, 'ivmContour', i);
end
for i = 1:options.extIters
  % Select the active set.
  model = ivmOptimiseIVM(model, options.display);
  if options.display > 1
    ivm3dPlot(model, 'ivmContour', i);
  end
  % Optimise the kernel parameters.
  model = ivmOptimiseKernel(model, options.display, options.kernIters);
end

model = ivmOptimiseIVM(model, options.display);
if options.display > 1
  ivm3dPlot(model, 'ivmContour', i);
end
% Display active points.
model = ivmOptimiseIVM(model, options.display);

% Display the model parameters.
ivmDisplay(model);
