function g = ivmNegGradientNoise(params, model)

% IVMNEGGRADIENTNOISE Wrapper function for calling noise param gradients.
%
% g = ivmNegGradientNoise(params, model)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmNegGradientNoise.m version 1.3



model.noise = noiseExpandParam(model.noise, params);
g = - noiseGradientParam(model.noise, model.mu, model.varSigma, model.y);
