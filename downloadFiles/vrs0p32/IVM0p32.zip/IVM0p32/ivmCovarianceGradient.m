function g = ivmCovarianceGradient(invK, m)

% IVMCOVARIANCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
%
% g = ivmCovarianceGradient(invK, m)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmCovarianceGradient.m version 1.1



invKm = invK*m;

g = -invK + invKm*invKm';
g= g*.5;
