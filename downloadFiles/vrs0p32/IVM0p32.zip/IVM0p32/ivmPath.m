% IVMPATH Brings dependent toolboxes into the path.
%
% 

% Copyright (c) 2005 Neil D. Lawrence
% ivmPath.m version 



importTool('kern');
importTool('noise');
importTool('ndlutil');
importTool('optimi');
importTool('prior');
importTool('rochol');
