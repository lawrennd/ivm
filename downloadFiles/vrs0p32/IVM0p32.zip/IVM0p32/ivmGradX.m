function g = ivmGradX(model, x, y);

% IVMGRADX Returns the gradient of the log-likelihood wrt x.
%
% g = ivmGradX(model, x, y);
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmGradX.m version 1.4



[mu, varsigma] = ivmPosteriorMeanVar(model, x);
[dmu, dvs] = ivmPosteriorGradMeanVar(model, x);

g = noiseGradX(model.noise, mu, varsigma, dmu, dvs, y);
