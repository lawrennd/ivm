function g = ivmKernelGradient(params, model)

% IVMKERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
%
% g = ivmKernelGradient(params, model)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmKernelGradient.m version 1.1




model.kern = kernExpandParam(model.kern, params);
g = ivmApproxLogLikeKernGrad(model);
g = g + kernPriorGradient(model.kern);
g = -g;

