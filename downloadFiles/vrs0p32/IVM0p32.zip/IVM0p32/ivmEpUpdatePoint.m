function model = ivmEpUpdatePoint(model, i)

% IVMEPUPDATEPOINT Do an EP update of a point.
%
% model = ivmEpUpdatePoint(model, i)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmEpUpdatePoint.m version 1.1



index = find(model.I == i);
if isempty(index)
  error(['Point ' num2str(i) ' is not in active set'])
end

% Set nu ready for the point removal.
model = ivmDowndateNuG(model, i);
model = ivmEpUpdateM(model, i);
