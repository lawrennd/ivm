function y = ivmOut(model, x);

% IVMOUT Evaluate the output of an ivm model.
%
% y = ivmOut(model, x);
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmOut.m version 1.2



if nargin < 2
  % This implies evaluate for the training data.
  mu = model.mu;
  varsigma = model.varSigma;
else
  [mu, varsigma] = ivmPosteriorMeanVar(model, x);
end

y = noiseOut(model.noise, mu, varsigma);
