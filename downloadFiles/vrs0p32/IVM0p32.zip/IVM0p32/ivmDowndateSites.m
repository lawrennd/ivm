function model = ivmDowndateSites(model, index)

% IVMDOWNDATESITES Downdate site parameters.
%
% model = ivmDowndateSites(model, index)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmDowndateSites.m version 1.1



model.m(index, :) = 0;
model.beta(index, :) = 0;