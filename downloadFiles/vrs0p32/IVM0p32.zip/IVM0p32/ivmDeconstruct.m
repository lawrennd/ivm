function [kern, noise, ivmInfo] = ivmDeconstruct(model)

% IVMDECONSTRUCT break IVM in pieces for saving.
%
% [kern, noise, ivmInfo] = ivmDeconstruct(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmDeconstruct.m version 1.2



kern = rmfield(model.kern, 'Kstore');
kern = rmfield(kern, 'diagK');
noise = model.noise;
ivmInfo.I = model.I;
ivmInfo.J = model.J;
ivmInfo.m = model.m;
ivmInfo.beta = model.beta;

