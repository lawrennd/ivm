function model = ivmEpOptimise(model, prior, display, innerIters, ...
			     outerIters, optimiseNoise);

% IVMEPOPTIMISE Optimise the IVM making use of point removal.
%
% model = ivmEpOptimise(model, prior, display, innerIters, ...
%			     outerIters, optimiseNoise);
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmEpOptimise.m version 1.1



if nargin < 6
  optimiseNoise = 1;
end
% Run IVM
for i = 1:outerIters
  model = ivmSelectPoints(model, display);
  model = ivmOptimiseKernel(model, prior, display, innerIters);
  if optimiseNoise
    model = ivmSelectPoints(model, display);
    model = ivmOptimiseNoise(model, prior, display, innerIters);
  end
  ivmDisplay(model);
end
