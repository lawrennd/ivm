function ivmDisplay(model)

% IVMDISPLAY Display parameters of ivm model.
%
% ivmDisplay(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmDisplay.m version 1.1



noiseDisplay(model.noise);
kernDisplay(model.kern);