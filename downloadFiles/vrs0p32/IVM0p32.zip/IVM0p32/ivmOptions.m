function options = ivmOptions(varargin)

% IVMOPTIONS Initialise an options structure.
%
% options = ivmOptions(varargin)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmOptions.m version 1.3



options.display = 0;
options.kernIters = 100;
options.noiseIters = 0;
options.extIters = 8;

