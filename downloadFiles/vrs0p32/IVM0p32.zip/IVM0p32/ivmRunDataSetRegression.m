function ivmRunDataSetRegression(dataSetName, experimentNo, kernelType, noiseModel, ...
                             selectionCriterion, dVal, seedVal);
                             
% IVMRUNDATASETREGRESSION Try the IVM on a data set and save the results.
%
% ivmRunDataSetRegression(dataSetName, experimentNo, kernelType, noiseModel, ...
%                             selectionCriterion, dVal, seedVal);
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmRunDataSetRegression.m version 



if nargin < 7
  seedVal = [];
  randn('seed', 1e5)
  rand('seed', 1e5)
else
  randn('seed', seedVal);
  rand('seed', seedVal);
end

jobId = getenv('PBS_JOBID');
jobName = getenv('PBS_JOBNAME');
fprintf('Seed %2.0e\n', seedVal);

if isempty(seedVal)
  [X, y, XTest, yTest] = ivmLoadData(dataSetName);
else
  [X, y, XTest, yTest] = ivmLoadData(dataSetName, seedVal);
end

capitalName = dataSetName;
capitalName(1) = upper(capitalName(1));

options = ivmOptions;

mu = zeros(size(yTest));
varSigma = zeros(size(yTest));

tic
model = ivmRun(X, y, kernelType, ...
               noiseModel, selectionCriterion, dVal, ...
               options);
  
runTime = toc;
if ~isempty(XTest) & ~isempty(yTest);
  [mu, varSigma] = ivmPosteriorMeanVar(model, XTest);
  yPred = mu + model.noise.bias;
  testError = 0.5*mean((yPred-yTest).^2);
  fprintf('Test error %2.4f, seed %2.4f, d %d\n', testError, ...
          seedVal, dVal);
end
[kern, noise, ivmInfo] = ivmDeconstruct(model);
save(['dem' capitalName '_' num2str(experimentNo) '_d' num2str(dVal) '_seed' num2str(seedVal)], 'testError', ...
     'ivmInfo', 'kern', 'noise', 'runTime', 'jobId', ...
     'jobName')
