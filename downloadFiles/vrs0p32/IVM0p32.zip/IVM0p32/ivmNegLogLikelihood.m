function e = ivmNegLogLikelihood(params, model)

% IVMNEGLOGLIKELIHOOD Wrapper function for calling ivm likelihoods.
%
% e = ivmNegLogLikelihood(params, model)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmNegLogLikelihood.m version 1.2



model.noise = noiseExpandParam(model.noise, params);
e = - ivmLogLikelihood(model);
