function f = ivmKernelObjective(params, model)

% IVMKERNELOBJECTIVE Likelihood approximation.
%
% f = ivmKernelObjective(params, model)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmKernelObjective.m version 1.1



model.kern = kernExpandParam(model.kern, params);
f = ivmApproxLogLikelihood(model);
f = f + kernPriorLogProb(model.kern);
f = -f;
