% IVM toolbox
% Version 0.32		Tuesday 22 Nov 2005 at 08:18
% Copyright (c) 2005 Neil D. Lawrence
% 
% DEMCLASSIFICATION1 Test IVM code on a toy feature selection
% DEMCLASSIFICATION2 IVM for classification on a data-set sampled from a GP.
% DEMCLASSIFICATION3 IVM for classification on a data-set sampled from a GP.
% DEMMLPMOUTHDATA2 Try on Ismael's vowels number 2.
% DEMMOUTHDATA2 Try on Ismael's vowels number 2.
% DEMORDERED1 Run a demonstration of the ordered categories noise model.
% DEMORDERED2 Run a demonstration of the ordered categories noise model.
% DEMPUMADYN1 Try the IVM on the pumadyn robot arm data.
% DEMPUMADYN2 Try the IVM on the pumadyn robot arm data.
% DEMPUMADYN3 Try the IVM on the pumadyn robot arm data.
% DEMPUMADYN3 Try the IVM on the pumadyn robot arm data.
% DEMPUMADYN1 Try the IVM on the pumadyn robot arm data.
% DEMREGRESSION1 The data-set is sampled from a GP with known parameters.
% DEMREGRESSION2 The data-set is sampled from a GP with known parameters.
% DEMREGRESSION3 The data-set is sampled from a GP with known parameters.
% DEMREGRESSION3 The data-set is sampled from a GP with known parameters.
% DEMUSPS1 Try the IVM on the USPS digits data.
% DEMUSPS2 Try the IVM on the USPS digits data.
% DEMUSPS3 Try the ARD IVM on some digits data.
% IVM Initialise an IVM model.
% IVM3DPLOT Make a 3-D or contour plot of the IVM.
% IVMADDPOINT Add a point.
% IVMAPPROXGRADX Returns the gradient of the approximat log-likelihood wrt x.
% IVMAPPROXLOGLIKEKERNGRAD Gradient of the approximate likelihood wrt kernel parameters.
% IVMAPPROXLOGLIKELIHOOD Return the approximate log-likelihood for the IVM.
% IVMCOMPUTEINFOCHANGE Compute the information change associated with each point.
% IVMCONTOUR Special contour plot showing decision boundary.
% IVMCOVARIANCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
% IVMDECONSTRUCT break IVM in pieces for saving.
% IVMDISPLAY Display parameters of ivm model.
% IVMDOWNDATEM Remove point from M, L, mu and varSigma.
% IVMDOWNDATENUG Downdate nu and g parameters associated with noise model.
% IVMDOWNDATESITES Downdate site parameters.
% IVMEPOPTIMISE Optimise the IVM making use of point removal.
% IVMEPUPDATEM Update matrix M, L, varSigma and mu for EP.
% IVMEPUPDATEPOINT Do an EP update of a point.
% IVMGRADX Returns the gradient of the log-likelihood wrt x.
% IVMGUNNARDATA Script for running experiments on Gunnar data.
% IVMINIT Initialise the IVM model.
% IVMKERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
% IVMKERNELOBJECTIVE Likelihood approximation.
% IVMLOGLIKELIHOODS Return the likelihood for each point for the IVM.
% IVMLOADDATA Load a dataset.
% IVMLOGLIKELIHOOD Return the log-likelihood for the IVM.
% IVMMESHVALS Give the output of the IVM for contour plot display.
% IVMNEGGRADIENTNOISE Wrapper function for calling noise param gradients.
% IVMNEGLOGLIKELIHOOD Wrapper function for calling ivm likelihoods.
% IVMOPTIMISE Optimise the IVM.
% IVMOPTIMISEIVM Selects the points for an IVM model.
% IVMOPTIMISEKERNEL Optimise the kernel parameters.
% IVMOPTIMISENOISE Optimise the noise parameters.
% IVMOPTIONS Initialise an options structure.
% IVMOUT Evaluate the output of an ivm model.
% IVMPATH Brings dependent toolboxes into the path.
% IVMPOSTERIORGRADMEANVAR Gradient of mean and variances of the posterior wrt X.
% IVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% IVMRECONSTRUCT Reconstruct an IVM form component parts.
% IVMRUN Run ivm on a data set.
% IVMRUNDATASET Try the IVM on a data set and save the results.
% IVMRUNDATASETREGRESSION Try the IVM on a data set and save the results.
% IVMRUNDATASETREGRESSION2 Try the IVM on a data set and save the results.
% IVMSELECTPOINT Choose a point for inclusion or removal.
% IVMSELECTPOINT Selects the point for an IVM.
% IVMSELECTVISUALISE Visualise the selected point.
% IVMTWODPLOT Make a 2-D plot of the IVM.
% IVMUPDATEM Update matrix M, L, v and mu.
% IVMUPDATENUG Update nu and g parameters associated with noise model.
% IVMUPDATESITES Update site parameters.
% IVMUSPSRESULTS Summarise the USPS result files in LaTeX.
% IVMVERS Brings dependent toolboxes into the path.
% IVMVIRTUAL Create virtual data points with the specified invariance.
% VIVMRUNDATASET Try the virtual IVM on a data set and save the results.
% VIVMRUNDATASETLEAN Try the virtual IVM on a data set and save the results.
% VIVMUSPSRESULTS Summarise the USPS result files in LaTeX.
