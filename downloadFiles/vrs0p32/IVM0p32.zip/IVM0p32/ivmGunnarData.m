function ivmGunnarData(dataSet, dataNum, kernelType, invWidth, dVal)

% IVMGUNNARDATA Script for running experiments on Gunnar data.
%
% ivmGunnarData(dataSet, dataNum, kernelType, invWidth, dVal)
%

% Copyright (c) 2005 Neil D. Lawrence
% ivmGunnarData.m version 



% Load the data
HOME = getenv('HOME');
fprintf('Dataset: %s, number %d, inverse width %2.4f', dataSet, dataNum, invWidth)
fs = filesep;
baseDir = [HOME filesep 'datasets' filesep 'gunnar' filesep dataSet filesep];
X=load([baseDir dataSet '_train_data_' num2str(dataNum) '.asc']);
y=load([baseDir dataSet '_train_labels_' num2str(dataNum) '.asc']);

% Define the noise model to be used
noiseModel='probit';
selectionCriterion='entropy';
% Define the kernel to be used
options = ivmOptions;
options.display = 0;
model=ivm(X, y, kernelType, noiseModel, selectionCriterion, dVal);
model.kern.comp{1}.inverseWidth = invWidth;
fprintf('Initial model:\n');
ivmDisplay(model);
for i = 1:15
  
  % Plot the data.
  % Select the active set.
  model = ivmOptimiseIVM(model, options.display);
  % Optimise the kernel parameters.
  model = ivmOptimiseKernel(model, options.display, 100);
  fprintf('Iteration %d\n', i);
  ivmDisplay(model);

end
model = ivmOptimiseIVM(model, options.display);
% Display the final model.
fprintf('Final model:\n');
ivmDisplay(model);
Xtest=load([baseDir dataSet '_test_data_' num2str(dataNum) '.asc']);
ytest=load([baseDir dataSet '_test_labels_' num2str(dataNum) '.asc']);

yPred = ivmOut(model, Xtest);
classError = 1- sum(ytest ==yPred)/length(ytest);

ll = ivmApproxLogLikelihood(model);
fprintf('Test Error %2.4f\n', classError);
fprintf('Model likelihood %2.4f\n', ll);
invWidthStr = num2str(invWidth);
ind = find(invWidthStr==46);
invWidthStr(ind) = 'p';
[kern, noise, ivmInfo] = ivmDeconstruct(model);
save(['ivm' dataSet num2str(dataNum) kernelType{1} invWidthStr], 'classError', 'll', ...
      'kern', 'noise', 'ivmInfo')
     