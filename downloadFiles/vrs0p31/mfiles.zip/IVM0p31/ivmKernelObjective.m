function f = ivmKernelObjective(params, model)

% IVMKERNELOBJECTIVE Likelihood approximation.
%
% f = ivmKernelObjective(params, model)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Jun 24 10:50:59 2004
% IVM toolbox version 0.31



model.kern = kernExpandParam(model.kern, params);
f = ivmApproxLogLikelihood(model);
f = f + kernPriorLogProb(model.kern);
f = -f;
