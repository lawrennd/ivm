function ivmContour(X, Y, Z, lineWidth)

% IVMCONTOUR Special contour plot showing decision boundary.
%
% ivmContour(X, Y, Z, lineWidth)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue Jun 22 14:05:57 2004
% IVM toolbox version 0.31



% It's probably learnt something.
[void, clines] =contour(X, Y, Z, [0.25 .75], 'b--');
set(clines, 'linewidth', lineWidth)
[void, clines] =contour(X, Y, Z, [0.5 0.5], 'r-');
set(clines, 'linewidth', lineWidth);
