function g = ivmKernelGradient(params, model)

% IVMKERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
%
% g = ivmKernelGradient(params, model)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Jun 21 15:36:44 2004
% IVM toolbox version 0.31




model.kern = kernExpandParam(model.kern, params);
g = ivmApproxLogLikeKernGrad(model);
g = g + kernPriorGradient(model.kern);
g = -g;

