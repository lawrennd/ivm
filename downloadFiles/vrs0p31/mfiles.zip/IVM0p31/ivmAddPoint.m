function model = ivmAddPoint(model, i)

% IVMADDPOINT Add a point.
%
% model = ivmAddPoint(model, i)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.5, Fri Apr 23 17:24:05 2004
% IVM toolbox version 0.31



index = find(model.J == i);
if isempty(index)
  error(['Point ' num2str(i) ' is not in inactive set'])
end

model = ivmUpdateSites(model, i);
model = ivmUpdateM(model, i);

% Remove point from the non-active set and place in the active.
model.J(index) = [];
model.I = [model.I; i];

model = ivmUpdateNuG(model, model.J);
