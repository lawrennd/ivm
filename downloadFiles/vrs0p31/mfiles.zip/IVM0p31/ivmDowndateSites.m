function model = ivmDowndateSites(model, index)

% IVMDOWNDATESITES Downdate site parameters.
%
% model = ivmDowndateSites(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri May 28 18:12:25 2004
% IVM toolbox version 0.31



model.m(index, :) = 0;
model.beta(index, :) = 0;