function [kern, noise, ivmInfo] = ivmDeconstruct(model, fileName)

% IVMSAVE break IVM in pieces for saving.
%
% [kern, noise, ivmInfo] = ivmDeconstruct(model, fileName)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Mar 15 20:57:49 2004
% IVM toolbox version 0.31



kern = rmfield(model.kern, 'Kstore');
kern = rmfield(kern, 'diagK');
noise = model.noise;
ivmInfo.I = model.I;
ivmInfo.J = model.J;
ivmInfo.m = model.m;
ivmInfo.beta = model.beta;

