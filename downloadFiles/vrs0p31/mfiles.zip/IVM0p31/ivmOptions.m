function options = ivmOptions(varargin)

% IVMOPTIONS Initialise an options structure.
%
% options = ivmOptions(varargin)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Mon Jul 12 17:58:20 2004
% IVM toolbox version 0.31



options.display = 0;
options.kernIters = 100;
options.noiseIters = 0;
options.extIters = 4;

