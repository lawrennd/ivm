function g = ivmNegGradientNoise(params, model)

% IVMNEGGRADIENTNOISE Wrapper function for calling noise param gradients.
%
% g = ivmNegGradientNoise(params, model)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Jun 18 14:22:07 2004
% IVM toolbox version 0.31



model.noise = noiseExpandParam(model.noise, params);
g = - noiseGradientParam(model.noise, model.mu, model.varSigma, model.y);
