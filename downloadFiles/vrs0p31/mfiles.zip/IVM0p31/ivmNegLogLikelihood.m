function e = ivmNegLogLikelihood(params, model)

% IVMNEGLOGLIKELIHOOD Wrapper function for calling ivm likelihoods.
%
% e = ivmNegLogLikelihood(params, model)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Fri Jun 18 14:21:48 2004
% IVM toolbox version 0.31



model.noise = noiseExpandParam(model.noise, params);
e = - ivmLogLikelihood(model);
