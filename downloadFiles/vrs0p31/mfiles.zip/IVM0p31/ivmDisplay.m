function ivmDisplay(model)

% IVMDISPLAY Display parameters of ivm model.
%
% ivmDisplay(model)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr 22 02:26:25 2004
% IVM toolbox version 0.31



noiseDisplay(model.noise);
kernDisplay(model.kern);