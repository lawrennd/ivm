function model = ivmDowndateNuG(model, index)

% IVMDOWNDATENUG Downdate nu and g parameters associated with noise model.
%
% model = ivmDowndateNuG(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri May 28 18:12:25 2004
% IVM toolbox version 0.31




model.nu(index, :) = 1./(1./model.beta(index, :) - model.varSigma(index, ...
						  :));
model.g(index, :) = model.nu(index, :)...
    .*(model.mu(index, :) - model.m(index, :));

