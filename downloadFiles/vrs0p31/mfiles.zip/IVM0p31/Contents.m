% IVM toolbox
% Version 0.31 Monday, July 12, 2004 at 19:31:18
% Copyright (c) 2004 Neil D. Lawrence
% 
% DEMCLASSIFICATION1 Test IVM code on a toy feature selection
% DEMCLASSIFICATION2 IVM for classification on a data-set sampled from a GP.
% DEMORDERED1 Run a demonstration of the ordered categories noise model.
% DEMORDERED2 Run a demonstration of the ordered categories noise model.
% DEMREGRESSION1 The data-set is sampled from a GP with known parameters.
% DEMREGRESSION2 The data-set is sampled from a GP with known parameters.
% DEMUSPS1 Try the IVM on the USPS digits data.
% DEMUSPS2 Try the IVM on the USPS digits data.
% DEMUSPS3 Try the ARD IVM on some digits data.
% IVM Initialise an IVM model.
% IVM3DPLOT Make a 3-D or contour plot of the IVM.
% IVMADDPOINT Add a point.
% IVMAPPROXGRADX Returns the gradient of the approximat log-likelihood wrt x.
% IVMAPPROXLOGLIKEKERNGRAD Gradient of the approximate likelihood wrt kernel parameters.
% IVMAPPROXLOGLIKELIHOOD Return the approximate log-likelihood for the IVM.
% IVMCOMPUTEINFOCHANGE Compute the information change associated with each point.
% IVMCONTOUR Special contour plot showing decision boundary.
% IVMCOVARIANCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
% IVMSAVE break IVM in pieces for saving.
% IVMDISPLAY Display parameters of ivm model.
% IVMDOWNDATEM Remove point from M, L, mu and varSigma.
% IVMDOWNDATENUG Downdate nu and g parameters associated with noise model.
% IVMDOWNDATESITES Downdate site parameters.
% IVMEPOPTIMISE Optimise the IVM making use of point removal.
% IVMEPUPDATEM Update matrix M, L, varSigma and mu for EP.
% IVMEPUPDATEPOINT Do an EP update of a point.
% IVMGRADX Returns the gradient of the log-likelihood wrt x.
% IVMINIT Initialise the IVM model.
% IVMKERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
% IVMKERNELOBJECTIVE Likelihood approximation.
% IVMLOGLIKELIHOODS Return the likelihood for each point for the IVM.
% IVMLOADDATA Load a dataset.
% IVMLOGLIKELIHOOD Return the log-likelihood for the IVM.
% IVMMESHVALS Give the output of the IVM for contour plot display.
% IVMNEGGRADIENTNOISE Wrapper function for calling noise param gradients.
% IVMNEGLOGLIKELIHOOD Wrapper function for calling ivm likelihoods.
% IVMOPTIMISE Optimise the IVM.
% IVMOPTIMISEIVM Selects the points for an IVM model.
% IVMOPTIMISEKERNEL Optimise the kernel parameters.
% IVMOPTIMISENOISE Optimise the noise parameters.
% IVMOPTIONS Initialise an options structure.
% IVMOUT Evaluate the output of an ivm model.
% IVMPOSTERIORGRADMEANVAR Gradient of mean and variances of the posterior wrt X.
% IVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% IVMLOAD Load an IVM structure.
% IVMRUN Run ivm on a data set.
% IVMSELECTPOINT Choose a point for inclusion or removal.
% IVMSELECTPOINT Selects the point for an IVM.
% IVMSELECTVISUALISE Visualise the selected point.
% IVMTWODPLOT Make a 2-D plot of the IVM.
% IVMUPDATEM Update matrix M, L, v and mu.
% IVMUPDATENUG Update nu and g parameters associated with noise model.
% IVMUPDATESITES Update site parameters.
