function g = ivmCovarianceGradient(invK, m)

% IVMCOVARIANCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
%
% g = ivmCovarianceGradient(invK, m)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun  9 18:58:02 2004
% IVM toolbox version 0.3



invKm = invK*m;

g = -invK + invKm*invKm';
g= g*.5;
