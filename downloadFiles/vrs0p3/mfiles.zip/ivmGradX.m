function g = ivmGradX(model, x, y);

% IVMGRADX Returns the gradient of the log-likelihood wrt x.
%
% g = ivmGradX(model, x, y);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Fri Apr 23 02:01:40 2004
% IVM toolbox version 0.3



[mu, varsigma] = ivmPosteriorMeanVar(model, x);
[dmu, dvs] = ivmPosteriorGradMeanVar(model, x);

g = noiseGradX(model.noise, mu, varsigma, dmu, dvs, y);
