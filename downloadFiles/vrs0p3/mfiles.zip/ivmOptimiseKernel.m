function model = ivmOptimiseKernel(model, prior, display, iters);

% IVMOPTIMISEKERNEL Optimise the kernel parameters.
%
% model = ivmOptimiseKernel(model, prior, display, iters);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.6, Mon Jun 14 21:03:03 2004
% IVM toolbox version 0.3



if nargin < 4
  iters = 500;
  if nargin < 3
    display = 1;
    if nargin < 2
      prior = 0;
    end
  end
end
options = foptions;
if display
  options(1) = 1;
end
options(14) = iters;


model = optimiseParams('kern', 'scg', 'kernelObjective', ...
                       'kernelGradient', options, model, prior);
  