function e = ivmNegLogLikelihood(params, model, prior)

% IVMNEGLOGLIKELIHOOD Wrapper function for calling ivm likelihoods.
%
% e = ivmNegLogLikelihood(params, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun  9 18:51:29 2004
% IVM toolbox version 0.3



model.noise = noiseExpandParam(model.noise, params);
e = - ivmLogLikelihood(model);

if prior
  e =e +0.5*params*params';
end