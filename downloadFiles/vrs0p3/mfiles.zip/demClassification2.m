% DEMCLASSIFICATION2 IVM for classification on a data-set sampled from a GP.
%
%
% Copyright (c) 2004 Neil D. Lawrence
% File version 1.8, Wed Jun 16 10:16:17 2004
% IVM toolbox version 0.3



% Sample a classification data-set.
[X, y ] = ivmLoadData('classificationTwo');
noiseModel = 'probit';
selectionCriterion = 'entropy';
kernelType = {'rbf', 'white'};
prior = 0;
display = 2;
dVal = 200;

% Initialise the IVM.
model = ivm(X, y, kernelType, noiseModel, selectionCriterion, dVal);
if display > 1
  ivm3dPlot(model, 'ivmContour', i);
end
for i = 1:4
  % Select the active set.
  model = ivmOptimiseIVM(model, display);
  if display > 1
    ivm3dPlot(model, 'ivmContour', i);
  end
  % Optimise the kernel parameters.
  model = ivmOptimiseKernel(model, prior, display, 100);
end

model = ivmOptimiseIVM(model, display);
if display > 1
  ivm3dPlot(model, 'ivmContour', i);
end
% Display active points.
model = ivmOptimiseIVM(model, display);

% Display the model parameters.
ivmDisplay(model);
