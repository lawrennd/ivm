function g = ivmNegGradientNoise(params, model, prior)

% IVMNEGGRADIENTNOISE Wrapper function for calling noise param gradients.
%
% g = ivmNegGradientNoise(params, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Fri Jun 18 13:50:25 2004
% IVM toolbox version 0.3



model.noise = noiseExpandParam(model.noise, params);
g = - noiseGradientParam(model.noise, model.mu, model.varSigma, model.y);

if prior
  g =g +params;
end