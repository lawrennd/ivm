function y = ivmOut(model, x);

% IVMOUT Evaluate the output of an ivm model.
%
% y = ivmOut(model, x);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr  5 02:45:12 2004
% IVM toolbox version 0.3



if nargin < 2
  % This implies evaluate for the traing data.
  mu = model.mu;
  varsigma = model.varSigma;
else
  [mu, varsigma] = ivmPosteriorMeanVar(model, x);
end

y = noiseOut(model.noise, mu, varsigma);
