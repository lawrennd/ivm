% DEMCLASSIFICATION3 IVM for classification on a data-set sampled from a GP.
%
%
% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% IVM toolbox version 0.3



% Sample a classification data-set.

noiseModel = 'probit';
selectionCriterion = 'entropy';
kernelType = {'rbf', 'white'};
prior = 0;
display = 0;
counteri = 0;
[X, y ] = ivmLoadData('classificationTwo');
for dVal = [100 200 400 600 800];
  counterj = 0;
  counteri = counteri + 1;
  for seedVal = 1:10
    counterj = counterj + 1;
    % Initialise the IVM.
    
    model = ivm(X, y, kernelType, noiseModel, selectionCriterion, dVal);
    randn('seed', seedVal*1e5);
    rand('seed', seedVal*1e5);
    for i = 1:4
      % Select the active set.
      model = ivmOptimiseIVM(model, display);
      % Optimise the kernel parameters.
      model = ivmOptimiseKernel(model, prior, display, 100);
    end
    
    kernStore(counteri, counterj) = model.kern.comp{1}.inverseWidth;
    % Display the model parameters.
    fprintf('Seed %d, d %d, kernel width %2.4f\n', seedVal, dVal, model.kern.comp{1}.inverseWidth)
    ivmDisplay(model);
  end
end
save demClassification3.mat kernStore