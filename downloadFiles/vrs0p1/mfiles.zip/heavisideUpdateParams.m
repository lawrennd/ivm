function model = heavisideUpdateParams(model, index)

% HEAVISIDEUPDATEPARAMS Update parameters for heaviside noise model.
%
% model = heavisideUpdateParams(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1


model.c(index) = model.y(index)./sqrt(model.varSigma(index));
model.u(index) = model.c(index).*(model.mu(index) + model.bias);
model.g(index) = model.c(index).*ngaussian(model.u(index))./(cummGaussian(model.u(index))+model.eta0/(1-model.eta0-model.eta1));
model.nu(index) = model.g(index).*(model.g(index) + model.c(index).*model.u(index));

