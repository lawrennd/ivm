function f = kernelObjective(lntheta, model, prior)

% KERNELOBJECTIVE Likelihood approximation.
%
% f = kernelObjective(lntheta, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



if nargin < 3
  prior = 1;
end
x = model.X(model.I, :);
m = model.m(model.I, :);
lntheta=log(thetaConstrain(exp(lntheta)));

K = kernel(x, lntheta, model.kernelType);
f = 0;
for i = 1:size(m, 2)
  if strcmp(model.noiseType, 'gaussian')
    % For Gaussians don't double count the noise.
    [invK, UC] = pdinv(K);
  else
    [invK, UC] = pdinv(K+diag(1./model.beta(model.I, i)));
  end
  f = f -.5*logdet(K, UC) - .5*m(:, i)'*invK*m(:, i);
end
if prior
  f = f - sum(lntheta);
end
f = -f;
