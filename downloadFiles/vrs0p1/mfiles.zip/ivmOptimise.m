function model = ivmOptimise(model, prior, display, innerIters, ...
			     outerIters);

% IVMOPTIMISE Optimise the IVM.
%
% model = ivmOptimise(model, prior, display, innerIters, ...
% 			     outerIters);

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



% Run IVM
for i = 1:outerIters
  model = ivmOptimiseIVM(model, display);
  model = ivmOptimiseKernel(model, prior, display, innerIters);
end
