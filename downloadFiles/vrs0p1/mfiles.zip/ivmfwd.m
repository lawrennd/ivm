function [y, a] = ivmfwd(x, model)

% IVMFWD Make out put predictions for the IVM
%
% [y, a] = ivmfwd(x, model)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



kx = kernel(model.X(model.I, :), model.lntheta, model.kernelType, x);
Linv = eye(length(model.I))/model.L;
beta = Linv'*Linv*model.m(model.I);

a = kx'*beta;
y = sign(a);

