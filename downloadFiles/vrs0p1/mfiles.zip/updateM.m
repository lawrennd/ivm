function model = updateM(model, index)

% UPDATEM Update matrix M, L, v and mu.
%
% model = updateM(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



activePoint = length(model.I)+1;
if length(model.I) > 0
  model.Kstore(:, activePoint) = kernel(model.X, model.lntheta, model.kernelType, ...
					model.X(index, :));
  model.Kstore(index, activePoint) = model.Kstore(index, activePoint) + exp(model.lntheta(3)); 

  a = model.M(:, index);
  s = model.Kstore(:, activePoint)' - a'*model.M;
  sqrtNu = sqrt(model.nu(index));
  model.M = [model.M; sqrtNu*s];
  ainv = (-a*sqrtNu)'/model.L;
  model.L = [[model.L; a'] [zeros(length(model.I),1); 1/sqrtNu]];
  model.Linv = [[model.Linv; ainv] [zeros(length(model.I),1); sqrtNu]];
  %/~
  %model.Linv = eye(size(model.L))/model.L;
  %~/
else

  model.Kstore(:, 1) = kernel(model.X, model.lntheta, model.kernelType, model.X(index, :));
  
  model.Kstore(index, 1) = model.Kstore(index, 1) + exp(model.lntheta(3));
  
  s = model.Kstore(:, 1)';

  model.M = [sqrt(model.nu(index))*s];

  model.L = sqrt(1/model.nu(index));
  model.Linv = 1/model.L;
end
model.varSigma = model.varSigma - model.nu(index)*(s.*s)';

model.mu = model.mu + model.g(index)*s';
