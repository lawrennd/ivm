% IVM toolbox
% Version 0.1 Wednesday, February 11, 2004 at 16:39:49
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.0 $
% 
% COMPUTEINFOCHANGE Compute the information change associated with each point.
% COVARINCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
% DEMCLASSIFICATION1 Test IVM code on a toy feature selection
% DEMCLASSIFICATION2 Try the IVM for classification.
% DIGITSDEMO Try the IVM on some digits data.
% DEMREGRESSION1 Try the IVM for regression.
% GAUSSIANUPDATEPARAMS Update parameters for probit noise model.
% GAUSSIANUPDATESITES Update sites for gaussian noise model.
% GENERATECLASSIFICATIONDATA Tries to load a sampled data set otherwise generates it.
% GENERATEREGRESSIONDATA Tries to load a sampled data set otherwise generates it.
% HEAVISIDEUPDATEPARAMS Update parameters for heaviside noise model.
% HEAVISIDEUPDATESITES Update site parameters for heaviside model.
% INITTHETA Initialise the kernel parameters.
% IVM Initialise an IVM model.
% IVMADDPOINT Add a point.
% IVMINIT Initialise the IVM model.
% IVMOPTIMISE Optimise the IVM.
% IVMOPTIMISEIVM Optimises an IVM model.
% IVMOPTIMISEKERNEL Optimise the kernel parameters.
% IVMRUN Run ivm on a data set.
% IVMFWD Make out put predictions for the IVM
% KERNEL Compute the kernel given the parameters and X.
% KERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
% KERNELOBJECTIVE Likelihood approximation.
% KERNELDIAG Compute the diagonal of the kernel.
% LOGDET The log of the determinant when argument is positive definite.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% PDINV Computes the inverse of a positive definite matrix
% PROBITUPDATEPARAMS Update parameters for probit noise model.
% PROBITUPDATESITES Update site parameters for probit model.
% THETACONSTRAIN Prevent kernel parameters from getting too big or small.
% UPDATEM Update matrix M, L, v and mu.
% UPDATESITES Update site parameters.
