function model = updateSites(model, index)

% UPDATESITES Update site parameters.
%
% model = updateSites(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



model.beta(index, :) = 1./(1./model.nu(index, :)-model.varSigma(index, :));
model.m(index, :) = model.mu(index, :) + model.g(index, :)./model.nu(index, :);
