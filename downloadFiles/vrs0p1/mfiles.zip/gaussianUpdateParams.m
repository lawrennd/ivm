function model = gaussianUpdateParams(model, index)

% GAUSSIANUPDATEPARAMS Update parameters for probit noise model.
%
% model = gaussianUpdateParams(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



model.nu(index, :) = model.beta(index, :)./(1+model.beta(index, :).* ...
				      model.varSigma(index, :));
model.g(index, :) = model.y(index, :) - model.mu(index, :);
model.g(index, :) = model.g(index, :).*model.nu(index, :);