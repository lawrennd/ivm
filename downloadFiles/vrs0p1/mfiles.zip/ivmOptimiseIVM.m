function model = ivmOptimiseIVM(model, display)

% IVMOPTIMISEIVM Optimises an IVM model.
%
% model = ivmOptimiseIVM(model, display)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



if nargin < 2
  display = 1;
end

model = ivmInit(model);
numData = size(model.X, 1);
model.J = 1:numData;

% Set first infoChange to NaN
infoChange(1) = NaN;

for k = 1:model.d
    
  switch model.selectionCriterion
   case 'random'
    indexSelect = ceil(rand(1)*length(model.J));
    infoChange(k) = -.5*log2(1-model.varSigma(indexSelect)*model.nu(indexSelect));
   case 'entropy' 
    delta = computeInfoChange(model);
    [infoChange(k), indexSelect] = max(delta);
    if sum(delta==infoChange(k))==length(delta);
      indexSelect = ceil(rand(1)*length(delta));
    end
  end
  i = model.J(indexSelect);
  
  model = ivmAddPoint(model, i);
  
  switch model.noiseType
   
   case 'probit'
     logLikelihoods = log(cummGaussian(model.u));
     dLogLikelihood(k) = sum(logLikelihoods);
     logLikelihoodRemain(k) = sum(logLikelihoods(model.J));
     falsePositives(k) = sum(sign(model.mu(model.J))~=model.y(model.J) & model.y(model.J)==1);
     trueNegatives(k) = sum(sign(model.mu(model.J))~=model.y(model.J) & model.y(model.J)==-1);
   case 'heaviside'
     logLikelihoods = log(cummGaussian(model.u)*(1-model.eta0-model.eta1)+model.eta0);
     dLogLikelihood(k) = sum(logLikelihoods);
     logLikelihoodRemain(k) = sum(logLikelihoods(model.J));
     falsePositives(k) = sum(sign(model.mu(model.J))~=model.y(model.J) & model.y(model.J)==1);
     trueNegatives(k) = sum(sign(model.mu(model.J))~=model.y(model.J) & model.y(model.J)==-1);
     
   case 'gaussian'
    logLikelihoods = -.5*log(2*pi) -.5*((model.y-model.mu).^2)./(1./model.beta ...
						  + model.varSigma) - .5*log(1./model.beta ...
						  +model.varSigma);
    dLogLikelihood(k) = sum(logLikelihoods);
    logLikelihoodRemain(k) = sum(logLikelihoods(model.J));
  end
  if display
    switch model.noiseType
     case 'gaussian'
      fprintf('%ith inclusion, remaining log likelihood %2.4f.\n', k, logLikelihoodRemain(k));
     case {'probit', 'heaviside'}
      fprintf(['%ith inclusion, remaining log Likelihood %2.4f, falsePos %2.4f, trueNeg' ...
	       ' %2.4f\n'], k, logLikelihoodRemain(k), falsePositives(k)./sum(model.y==1), trueNegatives(k)./sum(model.y==-1));
    end
    if display > 1
      if size(model.X, 2) == 2
	figure(2)
	plot(logLikelihoodRemain)
	
	figure(1)
	a = plot(model.X(i, 1), model.X(i, 2), 'o');
	set(a, 'erasemode', 'xor')
	xlim = get(gca, 'xlim');
	labelGap = (xlim(2) - xlim(1)) * 0.025;
	b = text(model.X(i, 1)+labelGap, model.X(i, 2), num2str(k));
	set(b, 'erasemode', 'xor')
      else
	subplot(10, 10, rem(k-1, 100)+1);
	image(round(reshape(model.X(i, :), 20, 20)*64))
	axis image
	axis off
      end
      drawnow 
    end
  end
end

