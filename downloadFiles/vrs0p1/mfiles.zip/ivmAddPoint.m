function model = ivmAddPoint(model, i)

% IVMADDPOINT Add a point.
%
% model = ivmAddPoint(model, i)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



index = find(model.J == i);
if isempty(index)
  error(['Point ' num2str(i) ' is not in inactive set'])
end

model = feval([model.noiseType 'UpdateSites'], model, i);
model = updateM(model, i);

% Remove point from the non-active set and place in the active.
model.J(index) = [];
model.I = [model.I; i];
  
model = feval([model.noiseType 'UpdateParams'], model, model.J);

