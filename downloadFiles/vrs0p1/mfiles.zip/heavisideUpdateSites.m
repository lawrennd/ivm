function model = heavisideUpdateSites(model, index)

% HEAVISIDEUPDATESITES Update site parameters for heaviside model.
%
% model = heavisideUpdateSites(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



model = heavisideUpdateParams(model, index);
model = updateSites(model, index);
