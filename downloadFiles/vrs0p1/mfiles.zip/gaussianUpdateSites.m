function model = gaussianUpdateSites(model, index)

% GAUSSIANUPDATESITES Update sites for gaussian noise model.
%
% model = gaussianUpdateSites(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



if nargin < 2
  index = 1:size(model.varSigma, 1);
end

model = gaussianUpdateParams(model, index);

% model.beta and model.m are already known and set