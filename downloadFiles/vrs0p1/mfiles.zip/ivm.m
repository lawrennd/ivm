function model = ivm(X, y, kernelType, noiseType, selectionCriterion, d)

% IVM Initialise an IVM model.
%
% model = ivm(X, y, kernelType, noiseType, selectionCriterion, d)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1


% Version 0.1

model.d = d;

model.X = X;
model.y = y;

model.m = [];
model.beta = [];

model.nu = zeros(size(y));
model.g = zeros(size(y));

model.Kstore = [];
model.diagK = zeros(size(y));
model.varSigma = zeros(size(y));
model.mu = zeros(size(y));

model.I = [];
model.J = [];

model.M = [];
model.L = [];

model.kernelType = kernelType;
model.noiseType = noiseType;
model.selectionCriterion = selectionCriterion;

model.lntheta = initTheta(kernelType, size(X, 2));

switch noiseType
 
 case 'gaussian'
  model.bias = mean(y);
 
 case {'probit','multiprobit'}
  model.u = zeros(size(y));
  model.c = zeros(size(y));
  nClass1 = sum(y==1, 1);
  nClass2 = sum(y==-1, 1);
  model.bias = invCummGaussian(nClass1./(nClass2+nClass1));
  
 case 'heaviside'
  model.u = zeros(size(y));
  model.c = zeros(size(y));
  nClass1 = sum(y==1);
  nClass2 = sum(y==-1);
  model.bias = invCummGaussian(nClass1./(nClass2+nClass1));
  model.eta0 = 0.0001;
  model.eta1 = 0.0001;
  
 otherwise
  nClass1 = sum(y==1);
  nClass2 = sum(y==-1);
  model.bias = invCummGaussian(nClass1./(nClass2+nClass1));

end

switch selectionCriterion
 case 'none'
  numData = size(X, 1);
  model.I = (1:numData);
 otherwise
  
end