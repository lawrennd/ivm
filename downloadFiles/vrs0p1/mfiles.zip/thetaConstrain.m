function theta = thetaConstrain(theta)

% THETACONSTRAIN Prevent kernel parameters from getting too big or small.
%
% theta = thetaConstrain(theta)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



if any(isnan(theta))
  error('Theta is not a number.')
end

minTheta = 1e-6;
maxTheta = 1/minTheta;

if any(theta < minTheta)
  theta(find(theta<minTheta)) = minTheta;
end
if any(theta>maxTheta)
  theta(find(theta>maxTheta)) = maxTheta;
end
