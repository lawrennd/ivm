function model = probitUpdateSites(model, index)

% PROBITUPDATESITES Update site parameters for probit model.
%
% model = probitUpdateSites(model, index)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



model = probitUpdateParams(model, index);
model = updateSites(model, index);