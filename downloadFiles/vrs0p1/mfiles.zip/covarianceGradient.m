function g = covarianceGradient(invK, m)

% COVARINCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
%
% g = covarianceGradient(invK, m)

% Copyright (c) 2004 Neil D. Lawrence
% File version 
% IVM toolbox version 0.1



invKm = invK*m;

g = -invK + invKm*invKm';
g= g*.5;
